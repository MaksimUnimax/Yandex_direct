(() => {
  "use strict";

  const RUN_STATUSES = Object.freeze({
    STARTING: "starting",
    WAITING_COMMAND: "waiting_command",
    REQUESTING: "requesting",
    DELIVERING: "delivering",
    PAUSED: "paused",
    STOPPED: "stopped",
    ERROR: "error"
  });

  const START_PHASES = Object.freeze({
    NONE: "none",
    COMMITTED: "committed",
    CONFIRMED: "confirmed"
  });

  const DELIVERY_PHASES = Object.freeze({
    CLAIMED: "claimed",
    COMMITTED: "committed",
    CONFIRMED: "confirmed"
  });

  function clampInteger(value, min, max, fallback = min) {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.max(min, Math.min(max, Math.trunc(number)));
  }

  function normalizeIdList(value, max = 5000) {
    const result = [];
    const seen = new Set();
    for (const item of Array.isArray(value) ? value : []) {
      const id = String(item || "").trim();
      if (!id || seen.has(id)) continue;
      seen.add(id);
      result.push(id.slice(0, 240));
      if (result.length >= max) break;
    }
    return result;
  }

  function normalizePrefixRecord(record) {
    if (!record) return null;
    const text = String(record.text || "").replace(/\r\n?/g, "\n");
    const enabled = record.enabled === true;
    if (enabled && !text.trim()) {
      const error = new Error("Включённый префикс результата не может быть пустым.");
      error.code = "EMPTY_REPORT_PREFIX";
      throw error;
    }
    return {
      enabled,
      text,
      interval: clampInteger(record.interval, 1, 999, 1),
      delivered_count: clampInteger(record.delivered_count, 0, Number.MAX_SAFE_INTEGER, 0),
      last_applied_at_count: clampInteger(record.last_applied_at_count, 0, Number.MAX_SAFE_INTEGER, 0),
      last_confirmed_delivery_id: String(record.last_confirmed_delivery_id || "").slice(0, 240) || null,
      updated_at: record.updated_at || new Date().toISOString()
    };
  }

  function reportPrefixIsDue(record) {
    if (record?.enabled !== true || !String(record.text || "").trim()) return false;
    const delivered = Math.max(0, Number(record.delivered_count || 0));
    const last = Math.max(0, Number(record.last_applied_at_count || 0));
    const interval = Math.max(1, Number(record.interval || 1));
    return delivered - last >= interval - 1;
  }

  function applyReportPrefix(outgoingText, record) {
    const clean = String(outgoingText || "");
    if (!reportPrefixIsDue(record)) return { text: clean, applied: false };
    return { text: `${String(record.text || "")}\n\n${clean}`, applied: true };
  }

  function noteConfirmedPrefix(record, applied, deliveryId = "") {
    const normalized = normalizePrefixRecord(record);
    if (!normalized) return null;
    const id = String(deliveryId || "").slice(0, 240);
    if (id && normalized.last_confirmed_delivery_id === id) return normalized;
    const deliveredCount = Math.max(0, Number(normalized.delivered_count || 0)) + 1;
    return {
      ...normalized,
      delivered_count: deliveredCount,
      last_applied_at_count: applied === true
        ? deliveredCount
        : Math.max(0, Number(normalized.last_applied_at_count || 0)),
      last_confirmed_delivery_id: id || normalized.last_confirmed_delivery_id || null,
      updated_at: new Date().toISOString()
    };
  }

  function isTerminalStatus(status) {
    return status === RUN_STATUSES.STOPPED || status === RUN_STATUSES.ERROR;
  }

  function isBusyStatus(status) {
    return status === RUN_STATUSES.STARTING ||
      status === RUN_STATUSES.WAITING_COMMAND ||
      status === RUN_STATUSES.REQUESTING ||
      status === RUN_STATUSES.DELIVERING;
  }

  function canEnableManualMode(status) {
    return !status || status === RUN_STATUSES.PAUSED || isTerminalStatus(status);
  }

  function pauseDecision(status) {
    if (status === RUN_STATUSES.WAITING_COMMAND) return "immediate";
    if (status === RUN_STATUSES.STARTING || status === RUN_STATUSES.REQUESTING || status === RUN_STATUSES.DELIVERING) return "deferred";
    if (status === RUN_STATUSES.PAUSED) return "already_paused";
    return "not_active";
  }

  function afterConfirmedStart(run, assistantBaselineIds = []) {
    const next = { ...run };
    next.start_delivery = {
      ...(run.start_delivery || {}),
      phase: START_PHASES.CONFIRMED,
      confirmed_at: new Date().toISOString()
    };
    next.assistant_baseline_ids = normalizeIdList(assistantBaselineIds);
    next.watch_id = `watch-${globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2)}`;
    if (next.finish_requested === true) {
      next.status = RUN_STATUSES.STOPPED;
      next.finish_requested = false;
      next.pause_requested = false;
      return next;
    }
    if (next.pause_requested === true) {
      next.status = RUN_STATUSES.PAUSED;
      next.pause_requested = false;
      return next;
    }
    next.status = RUN_STATUSES.WAITING_COMMAND;
    return next;
  }

  function commitStart(run, { baselineUserTurnIds = [], actorId = "" } = {}) {
    if (!run || run.status !== RUN_STATUSES.STARTING) return run;
    const existing = run.start_delivery || {};
    if ([START_PHASES.COMMITTED, START_PHASES.CONFIRMED].includes(existing.phase)) return run;
    return {
      ...run,
      start_delivery: {
        ...existing,
        phase: START_PHASES.COMMITTED,
        baseline_user_turn_ids: normalizeIdList(baselineUserTurnIds),
        commit_actor_id: String(actorId || "").slice(0, 240) || null,
        committed_at: new Date().toISOString()
      }
    };
  }

  function claimDelivery(run, payload = {}) {
    if (!run) return run;
    return {
      ...run,
      status: RUN_STATUSES.DELIVERING,
      delivery: {
        delivery_id: String(payload.deliveryId || ""),
        phase: DELIVERY_PHASES.CLAIMED,
        request_id: String(payload.requestId || ""),
        outgoing_text: String(payload.outgoingText || ""),
        outgoing_hash: String(payload.outgoingHash || ""),
        report_prefix_applied: payload.reportPrefixApplied === true,
        baseline_user_turn_ids: [],
        commit_actor_id: null,
        claimed_at: new Date().toISOString()
      }
    };
  }

  function commitDelivery(run, { deliveryId = "", baselineUserTurnIds = [], actorId = "" } = {}) {
    if (!run || run.status !== RUN_STATUSES.DELIVERING || run.delivery?.delivery_id !== deliveryId) return run;
    if ([DELIVERY_PHASES.COMMITTED, DELIVERY_PHASES.CONFIRMED].includes(run.delivery.phase)) return run;
    if (run.delivery.phase !== DELIVERY_PHASES.CLAIMED) return run;
    return {
      ...run,
      delivery: {
        ...run.delivery,
        phase: DELIVERY_PHASES.COMMITTED,
        baseline_user_turn_ids: normalizeIdList(baselineUserTurnIds),
        commit_actor_id: String(actorId || "").slice(0, 240) || null,
        committed_at: new Date().toISOString()
      }
    };
  }

  function recoveryDecision(run, workerSessionId = "") {
    if (!run || isTerminalStatus(run.status)) return { type: "none" };
    if (run.status === RUN_STATUSES.WAITING_COMMAND) return { type: "watch" };
    if (run.status === RUN_STATUSES.PAUSED) return { type: "paused" };
    if (run.status === RUN_STATUSES.STARTING) {
      const phase = run.start_delivery?.phase || START_PHASES.NONE;
      if (phase === START_PHASES.NONE) return { type: "dispatch_start" };
      if (phase === START_PHASES.COMMITTED) return { type: "reconcile_start" };
      if (phase === START_PHASES.CONFIRMED) return { type: "watch" };
      return { type: "blocked", code: "UNKNOWN_START_PHASE" };
    }
    if (run.status === RUN_STATUSES.REQUESTING) {
      if (run.request_worker_session_id && workerSessionId && run.request_worker_session_id !== workerSessionId) {
        return { type: "unsafe_request_outcome", code: "REQUEST_OUTCOME_UNKNOWN_NO_RETRY" };
      }
      return { type: "request_in_progress" };
    }
    if (run.status === RUN_STATUSES.DELIVERING) {
      if (run.delivery?.phase === DELIVERY_PHASES.CLAIMED) return { type: "deliver_claimed" };
      if (run.delivery?.phase === DELIVERY_PHASES.COMMITTED) return { type: "reconcile_delivery" };
      if (run.delivery?.phase === DELIVERY_PHASES.CONFIRMED) return { type: "watch" };
      return { type: "blocked", code: "UNKNOWN_DELIVERY_PHASE" };
    }
    return { type: "blocked", code: "UNKNOWN_RUN_STATUS" };
  }

  function afterConfirmedDelivery(run) {
    const next = { ...run };
    next.sequence = Math.max(0, Number(next.sequence || 0)) + 1;
    if (next.finish_requested === true) {
      next.status = RUN_STATUSES.STOPPED;
      next.finish_requested = false;
      next.pause_requested = false;
      return next;
    }
    if (next.pause_requested === true) {
      next.status = RUN_STATUSES.PAUSED;
      next.pause_requested = false;
      return next;
    }
    next.status = RUN_STATUSES.WAITING_COMMAND;
    return next;
  }

  const model = Object.freeze({
    RUN_STATUSES,
    START_PHASES,
    DELIVERY_PHASES,
    normalizeIdList,
    normalizePrefixRecord,
    reportPrefixIsDue,
    applyReportPrefix,
    noteConfirmedPrefix,
    isTerminalStatus,
    isBusyStatus,
    canEnableManualMode,
    pauseDecision,
    commitStart,
    afterConfirmedStart,
    claimDelivery,
    commitDelivery,
    recoveryDecision,
    afterConfirmedDelivery
  });

  globalThis.MarketingAutorunModel = model;
  // Phase 1 compatibility alias: remove only after the Wordstat migration acceptance gate.
  globalThis.WordstatAutorunModel = model;
})();
