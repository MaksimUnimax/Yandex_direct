# Yandex Marketing Bridge 0.1.10 candidate QA

Candidate-only review bundle. No browser extension was installed, no live ChatGPT flow was run, and no provider/API request or credential was used. All delivery inputs and DOM states are synthetic and de-identified.

## Source and scope integrity

- Input archive: `yandex_input/Yandex-Marketing-Bridge-0.1.9.zip`
- Input archive SHA-256: `de4425a47645d537ef7b69994ef2df0f66c3e9bd6741b0b47884426bdd954c4c`
- The supplied `source/` tree was compared with a fresh extraction of that ZIP; no differences were found.
- Production modifications are limited to the scoped files: `README.md`, `README.txt`, `content_script.js`, `file_delivery_content.js`, `file_delivery_worker_transport.js`, `manifest.json`, `package.json`, `popup.css`, `popup.js`, `popup_context_bootstrap.js`, `service_worker.js`, `shared/chatgpt_file_attachment.js`, `shared/composer_send.js`, `shared/conversation_identity.js`, `shared/product.js`, and `shared/proven_writing_block_capture.js`.
- Added production helper: `shared/dot_surface.js`.
- SHA-256 comparison against the source tree found no changed or added production paths outside that allowlist. Other added paths are isolated candidate tests and QA logs.
- Manifest and package version are `0.1.10`. The new helper is in the same relative order in manifest and popup manual-injection helper lists.

## Automated checks

- `npm test`: **16 passed, 0 failed** (`node --test tests/*.test.mjs`). Full output: `qa/npm-test.log`.
- `node --check` on all JavaScript and MJS files: passed. Output: `qa/syntax-check.log`.
- `unzip -t` on the input ZIP: passed.
- Original ZIP package references `../tests/*.test.mjs`, but no `tests/` directory is present in the supplied ZIP. That unavailable upstream suite was not claimed as run; this candidate uses an isolated in-folder test suite.

## Coverage

- Exact ChatGPT `/dots/<UUID>` identity namespace and fail-closed canonical conflicts; `/c/` identity remains distinct.
- Dot UI helper/capture requires a visible non-self assistant message-row code block with its native Copy control; user/self rows, hidden/detached nodes, unrelated copy controls and unknown attachment children fail closed.
- Composer and file-input selection are constrained to the unique Dot composer/footer; ambiguous attachment siblings, upload states, and present-but-empty error attributes fail closed.
- Real phase-3/service-worker/file-delivery worker import chain with mocked Chrome storage and IndexedDB. Tests verify full UTF-8 TXT bytes/chunk hashes, file-only history baseline, identity/owner fences, raw content-error outbox delivery, send rollback retaining the original baseline, exact send acknowledgement and subsequent Manual admission. Provider fetch count is asserted zero.
- Real `file_delivery_content.js` DOM runtime paths: `auto_send=false` waits for the intercepted user click; `auto_send=true` sends exactly once; committed recovery only completes and never attaches/clicks again.
- Durable Dot completion receipt crash recovery after outbox clear, receipt write failure before clear, receipt update failure after clear, exact operation/delivery/owner/status mismatch fencing before receipt/cleanup, restart reconciliation and next-operation unlock.
- `/c/` plain-text threshold regression at 1,048,000 characters and one-character-over behavior.

## Limits

These checks establish only synthetic implementation behavior and scoped source integrity. They do not establish compatibility with a live ChatGPT DOM, a live provider, or production service behavior.
