/* global YMBFileArtifactStore */
(() => {
  "use strict";

  const basePutOutbox = putOutbox;
  const baseClearOutbox = clearOutbox;
  const baseHandleMessage = handleMessage;
  const baseExecuteManualBlock = executeManualBlock;
  const baseHandleAutoCommand = handleAutoCommand;
  const CHATGPT_FILE_TEXT_THRESHOLD = 1_048_000;
  const DELIVERY_MODE = "attachment_v2";
  const SEND_COMMITTED_PHASE = "attachment_send_committed";
  const DOT_COMPLETION_RECEIPTS_KEY = "ymb_dot_delivery_completion_receipts";

  function unicodeLengthExceeds(value, limit) {
    let count = 0;
    for (const _character of String(value ?? "")) { count += 1; if (count > limit) return true; }
    return false;
  }

  function safeFilename(value, fallback = "yandex-bridge-result.txt") {
    const raw = String(value || "").replace(/[\u0000-\u001f\u007f]/g, "").replace(/[\\/]/g, "_").trim();
    const clean = raw.replace(/^\.+/, "").replace(/\.{2,}/g, ".").slice(0, 180);
    return clean && clean !== "." && clean !== ".." ? clean : fallback;
  }

  function bytesToBase64(bytes) {
    const source = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    let binary = ""; const step = 0x8000;
    for (let offset = 0; offset < source.length; offset += step) binary += String.fromCharCode(...source.subarray(offset, Math.min(source.length, offset + step)));
    return btoa(binary);
  }

  function isDotKey(value) { return normalizeConversationKey(value).toLowerCase().includes("|dots:"); }

  function validDotBaseline(entry) {
    const messageIds = Array.isArray(entry?.baseline_message_ids) ? entry.baseline_message_ids.map((id) => String(id || "").trim()) : [];
    const selfIds = Array.isArray(entry?.baseline_self_message_ids) ? entry.baseline_self_message_ids.map((id) => String(id || "").trim()) : [];
    const userIds = Array.isArray(entry?.baseline_user_turn_ids) ? entry.baseline_user_turn_ids.map((id) => String(id || "").trim()) : [];
    const anchor = String(entry?.baseline_last_message_id || "").trim();
    return entry?.baseline_captured === true && entry?.baseline_identity_key === entry?.conversation_key &&
      messageIds.length > 0 && messageIds.every(Boolean) && new Set(messageIds).size === messageIds.length &&
      selfIds.every(Boolean) && new Set(selfIds).size === selfIds.length && selfIds.every((id) => messageIds.includes(id)) &&
      JSON.stringify(selfIds) === JSON.stringify(userIds) &&
      anchor === messageIds[messageIds.length - 1];
  }

  function sameStringMultiset(left, right) {
    const a = (Array.isArray(left) ? left : []).map((value) => String(value || "").trim()).sort();
    const b = (Array.isArray(right) ? right : []).map((value) => String(value || "").trim()).sort();
    return a.length === b.length && a.every((value, index) => value === b[index]);
  }

  async function prepareEntry(entry, conversationKey = "") {
    let next = { ...(entry || {}) };
    const deliveryId = String(next.delivery_id || uid("delivery"));
    next.delivery_id = deliveryId;
    if (Array.isArray(next.artifact_descriptors) && next.artifact_descriptors.length) return next;
    const text = String(next.report_text || "");
    const dotFile = Boolean(conversationKey && isDotKey(conversationKey) && text.length > 0);
    if (!dotFile && !unicodeLengthExceeds(text, CHATGPT_FILE_TEXT_THRESHOLD)) return next;
    const filename = safeFilename(`yandex-bridge-${String(next.type || "result")}-${deliveryId}.txt`);
    const descriptor = await YMBFileArtifactStore.stageTextArtifact({ artifactKey: `delivery:${deliveryId}:0`, deliveryId, filename, mimeType: "text/plain;charset=utf-8", text });
    return { ...next, delivery_mode: DELIVERY_MODE, artifact_descriptors: [descriptor], report_text: `Yandex Marketing Bridge: результат прикреплён файлом ${filename}.` };
  }

  putOutbox = async function fileAwarePutOutbox(conversationKey, entry) {
    const key = normalizeConversationKey(conversationKey);
    const previous = await getConversationOutbox(key);
    const entryHadArtifacts = Array.isArray(entry?.artifact_descriptors) && entry.artifact_descriptors.length > 0;
    const prepared = await prepareEntry(entry, key);
    const stagedHere = !entryHadArtifacts && prepared.delivery_mode === DELIVERY_MODE ? (prepared.artifact_descriptors || []) : [];
    let stored;
    try { stored = await basePutOutbox(key, prepared); }
    catch (error) { if (stagedHere.length) await YMBFileArtifactStore.cleanupDescriptors(stagedHere).catch(() => null); throw error; }
    if (previous?.delivery_mode === DELIVERY_MODE && previous.delivery_id !== stored?.delivery_id) await YMBFileArtifactStore.cleanupDescriptors(previous.artifact_descriptors || []).catch(() => null);
    return stored;
  };

  clearOutbox = async function fileAwareClearOutbox(conversationKey, deliveryId = null) {
    const key = normalizeConversationKey(conversationKey);
    const previous = await getConversationOutbox(key);
    await baseClearOutbox(key, deliveryId);
    if (previous?.delivery_mode === DELIVERY_MODE && (!deliveryId || previous.delivery_id === deliveryId)) await YMBFileArtifactStore.cleanupDescriptors(previous.artifact_descriptors || []).catch(() => null);
  };

  function compactLargeCommandResult(value, force = false) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return value;
    const text = typeof value.report_text === "string" ? value.report_text : "";
    if (!force && !unicodeLengthExceeds(text, CHATGPT_FILE_TEXT_THRESHOLD)) return value;
    const out = {};
    for (const field of ["ok", "accepted", "duplicate", "busy", "ignored", "paused", "skipped", "error_delivery", "code", "error", "reason", "request_id", "operation_id", "delivery_id", "request_executed", "confirmed_provider_executions", "provider_executions"]) if (Object.hasOwn(value, field)) out[field] = value[field];
    out.report_text = "Yandex Marketing Bridge: большой результат сохранён для файловой доставки; полный payload не возвращается через runtime message.";
    if (value.result && typeof value.result === "object") {
      out.result = {};
      for (const field of ["ok", "request_id", "http_status", "request_executed", "automatic_retry"]) if (Object.hasOwn(value.result, field)) out.result[field] = value.result[field];
    }
    if (value.run && typeof value.run === "object") out.run = { run_id: value.run.run_id || null, status: value.run.status || null, active_service: value.run.active_service || null, sequence: value.run.sequence ?? null };
    return out;
  }

  async function compactConfirmedDotReport(value, conversationKey) {
    const key = normalizeConversationKey(conversationKey);
    if (!isDotKey(key) || !value || typeof value !== "object" || Array.isArray(value) || !String(value.report_text || "")) return value;
    const entry = await getConversationOutbox(key);
    if (entry?.delivery_mode !== DELIVERY_MODE || !Array.isArray(entry.artifact_descriptors) || !entry.artifact_descriptors.length) return value;
    if (value.delivery_id && String(value.delivery_id) !== String(entry.delivery_id)) return value;
    if (value.accepted === false || !(value.accepted === true || value.error_delivery === true || String(value.delivery_id || "") === String(entry.delivery_id))) return value;
    const filenames = entry.artifact_descriptors.map((item) => safeFilename(item?.filename)).filter(Boolean);
    const caption = filenames.length === 1
      ? `Yandex Marketing Bridge: результат прикреплён файлом ${filenames[0]}.`
      : filenames.length > 1
        ? `Yandex Marketing Bridge: результаты прикреплены файлами ${filenames.join(", ")}.`
        : "Yandex Marketing Bridge: результат сохранён для файловой доставки.";
    return compactLargeCommandResult({ ...value, report_text: caption }, true);
  }

  executeManualBlock = async function fileAwareExecuteManualBlock(...args) {
    const result = await baseExecuteManualBlock(...args);
    return await compactConfirmedDotReport(result, args[1]);
  };
  handleAutoCommand = async function fileAwareHandleAutoCommand(...args) {
    const result = await baseHandleAutoCommand(...args);
    const key = args[0]?.conversation_key;
    return await compactConfirmedDotReport(result, key);
  };

  let mutationTail = Promise.resolve();
  let mutationCount = 0;
  function serializeMutation(work) {
    if (mutationCount >= 16) return Promise.resolve({ ok: false, code: "ATTACHMENT_CONTROL_BUSY" });
    mutationCount++;
    const task = mutationTail.then(work);
    mutationTail = task.catch(() => null);
    return task.finally(() => { mutationCount--; });
  }

  async function ownedAttachment(message, sender, allowPaused = false) {
    const key = normalizeConversationKey(message.conversation_key);
    const outbox = await getOutbox();
    const entry = outbox[key] || null;
    if (!entry || entry.delivery_id !== String(message.delivery_id || "")) return { key, entry: null, error: { ok: false, code: "DELIVERY_NOT_FOUND" } };
    const ownerFence = await outboxOwnerFence(entry, key, sender);
    if (ownerFence) return { key, entry, error: ownerFence };
    if (entry.delivery_mode !== DELIVERY_MODE) return { key, entry, error: { ok: false, code: "ATTACHMENT_MODE_REQUIRED" } };
    if (!allowPaused && entry.delivery_paused === true) return { key, entry, error: { ok: false, code: "ATTACHMENT_DELIVERY_PAUSED", request_executed: false } };
    return { key, entry, error: null };
  }

  async function attachmentChunk(message, sender) {
    const owned = await ownedAttachment(message, sender);
    if (owned.error) return owned.error;
    const descriptor = (owned.entry.artifact_descriptors || []).find((item) => String(item.artifact_key) === String(message.artifact_key || ""));
    if (!descriptor) return { ok: false, code: "OUTBOX_ARTIFACT_NOT_DECLARED" };
    const index = Number(message.chunk_index);
    const expected = (descriptor.chunk_manifest || []).find((item) => Number(item.chunk_index) === index);
    if (!expected) return { ok: false, code: "OUTBOX_ARTIFACT_CHUNK_NOT_DECLARED" };
    const chunk = await YMBFileArtifactStore.getChunk(descriptor.artifact_key, index);
    if (chunk.byte_length !== Number(expected.byte_length) || chunk.sha256 !== String(expected.sha256 || "")) return { ok: false, code: "OUTBOX_ARTIFACT_CHUNK_INTEGRITY_MISMATCH" };
    const stillOwned = await ownedAttachment(message, sender);
    if (stillOwned.error) return stillOwned.error;
    return { ok: true, artifact_key: descriptor.artifact_key, chunk_index: index, byte_length: chunk.byte_length, sha256: chunk.sha256, total_byte_length: Number(descriptor.byte_length || 0), chunk_base64: bytesToBase64(chunk.bytes) };
  }

  async function markAttachmentCommitted(message, sender) {
    const owned = await ownedAttachment(message, sender);
    if (owned.error) return owned.error;
    if (["attachment_committed", "attachment_ready", SEND_COMMITTED_PHASE, "committed"].includes(owned.entry.phase)) return { ok: true, already_committed: true, outbox: owned.entry };
    if (owned.entry.phase !== "claimed") return { ok: false, code: "ATTACHMENT_PHASE_INVALID" };
    let baseline = {};
    if (isDotKey(owned.key)) {
      const messageIds = Array.isArray(message.baseline_message_ids) ? message.baseline_message_ids.map((id) => String(id || "").trim()) : [];
      const selfIds = Array.isArray(message.baseline_self_message_ids) ? message.baseline_self_message_ids.map((id) => String(id || "").trim()) : [];
      const anchor = String(message.baseline_last_message_id || "").trim();
      baseline = { baseline_message_ids: messageIds, baseline_self_message_ids: selfIds, baseline_user_turn_ids: selfIds, baseline_last_message_id: anchor, baseline_captured: message.baseline_captured === true, baseline_identity_key: String(message.baseline_identity_key || "") };
      if (!validDotBaseline({ ...owned.entry, ...baseline })) return { ok: false, code: "DOT_MESSAGE_BASELINE_INVALID" };
      if (owned.entry.baseline_captured === true && (!validDotBaseline(owned.entry) || JSON.stringify(owned.entry.baseline_message_ids) !== JSON.stringify(messageIds) || JSON.stringify(owned.entry.baseline_self_message_ids) !== JSON.stringify(selfIds) || owned.entry.baseline_last_message_id !== anchor)) return { ok: false, code: "DOT_MESSAGE_BASELINE_MISMATCH" };
    }
    const next = await putOutbox(owned.key, { ...owned.entry, ...baseline, phase: "attachment_committed", attachment_committed_at: nowIso() });
    return { ok: true, outbox: next };
  }

  async function markAttachmentReady(message, sender) {
    const owned = await ownedAttachment(message, sender);
    if (owned.error) return owned.error;
    if (["attachment_ready", SEND_COMMITTED_PHASE, "committed"].includes(owned.entry.phase)) return { ok: true, already_ready: true, outbox: owned.entry };
    if (owned.entry.phase !== "attachment_committed") return { ok: false, code: "ATTACHMENT_PHASE_INVALID" };
    if (isDotKey(owned.key) && !validDotBaseline(owned.entry)) return { ok: false, code: "DOT_MESSAGE_BASELINE_MISSING" };
    const expected = (owned.entry.artifact_descriptors || []).map((item) => String(item.filename));
    const actual = Array.isArray(message.attached_filenames) ? message.attached_filenames.map(String) : [];
    if (isDotKey(owned.key) ? !sameStringMultiset(expected, actual) : JSON.stringify(expected) !== JSON.stringify(actual)) return { ok: false, code: "ATTACHMENT_FILESET_MISMATCH" };
    const next = await putOutbox(owned.key, { ...owned.entry, phase: "attachment_ready", attached_filenames: actual, attachment_ready_at: nowIso() });
    return { ok: true, outbox: next };
  }

  async function commitAttachmentSend(message, sender) {
    const owned = await ownedAttachment(message, sender);
    if (owned.error) return owned.error;
    if (owned.entry.phase === "committed") return { ok: true, already_confirmed: true, outbox: owned.entry };
    if (owned.entry.phase === SEND_COMMITTED_PHASE) return { ok: true, already_committed: true, outbox: owned.entry };
    if (owned.entry.phase !== "attachment_ready") return { ok: false, code: "ATTACHMENT_NOT_READY" };
    const expected = (owned.entry.artifact_descriptors || []).map((item) => String(item.filename));
    const provided = Array.isArray(message.expected_attachment_names) ? message.expected_attachment_names.map(String) : expected;
    if (isDotKey(owned.key)) {
      if (!validDotBaseline(owned.entry)) return { ok: false, code: "DOT_MESSAGE_BASELINE_MISSING" };
      if (!sameStringMultiset(expected, provided)) return { ok: false, code: "ATTACHMENT_FILESET_MISMATCH" };
      if (!sameStringMultiset(expected, owned.entry.attached_filenames)) return { ok: false, code: "ATTACHMENT_READY_FILESET_MISMATCH" };
    } else if (JSON.stringify(expected) !== JSON.stringify(provided)) return { ok: false, code: "ATTACHMENT_FILESET_MISMATCH" };
    const next = await putOutbox(owned.key, {
      ...owned.entry,
      phase: SEND_COMMITTED_PHASE,
      attachment_send_committed_at: nowIso(),
      send_marker: String(message.send_marker || owned.entry.report_text || ""),
      ...(isDotKey(owned.key) ? {} : { baseline_message_ids: Array.isArray(message.baseline_message_ids) ? message.baseline_message_ids.map(String).slice(0, 1000) : [] }),
      expected_attachment_names: provided,
      send_target_fingerprint: message.send_target_fingerprint || null,
      send_click_dispatched: false
    });
    return { ok: true, outbox: next };
  }

  async function markAttachmentClickDispatched(message, sender) {
    const owned = await ownedAttachment(message, sender);
    if (owned.error) return owned.error;
    if (owned.entry.phase === "committed") return { ok: true, already_confirmed: true, outbox: owned.entry };
    if (owned.entry.phase !== SEND_COMMITTED_PHASE) return { ok: false, code: "ATTACHMENT_SEND_NOT_COMMITTED" };
    if (owned.entry.send_click_dispatched === true) return { ok: true, already_dispatched: true, outbox: owned.entry };
    const next = await putOutbox(owned.key, { ...owned.entry, send_click_dispatched: true, send_click_dispatched_at: nowIso(), send_click_trace: message.send_click_trace || null });
    return { ok: true, outbox: next };
  }

  async function rollbackAttachmentSend(message, sender) {
    const owned = await ownedAttachment(message, sender);
    if (owned.error) return owned.error;
    if (owned.entry.phase !== SEND_COMMITTED_PHASE) return { ok: false, code: "ATTACHMENT_SEND_NOT_COMMITTED" };
    if (owned.entry.send_click_dispatched === true) return { ok: false, code: "ATTACHMENT_SEND_DISPATCHED_NO_ROLLBACK" };
    const next = { ...owned.entry, phase: "attachment_ready", attachment_send_rollback_at: nowIso() };
    for (const field of ["attachment_send_committed_at", "send_marker", "expected_attachment_names", "send_target_fingerprint", "send_click_dispatched", "send_click_dispatched_at", "send_click_trace"]) delete next[field];
    if (!isDotKey(owned.key)) delete next.baseline_message_ids;
    const stored = await putOutbox(owned.key, next);
    return { ok: true, outbox: stored };
  }

  async function confirmAttachmentSend(message, sender) {
    const owned = await ownedAttachment(message, sender, true);
    if (owned.error) return owned.error;
    if (owned.entry.phase === "committed") return { ok: true, already_confirmed: true, outbox: owned.entry };
    if (owned.entry.phase !== SEND_COMMITTED_PHASE) return { ok: false, code: "ATTACHMENT_SEND_NOT_COMMITTED" };
    if (isDotKey(owned.key)) {
      const confirmedId = String(message.confirmation_message_id || "").trim();
      if (!validDotBaseline(owned.entry) || !confirmedId || owned.entry.baseline_message_ids.includes(confirmedId)) return { ok: false, code: "DOT_CONFIRMATION_ID_INVALID" };
      const ordered = Array.isArray(message.confirmation_ordered_message_ids) ? message.confirmation_ordered_message_ids.map((id) => String(id || "").trim()) : [];
      if (!ordered.length || ordered.some((id) => !id) || new Set(ordered).size !== ordered.length) return { ok: false, code: "DOT_CONFIRMATION_ORDER_INVALID" };
      const anchorIndex = ordered.indexOf(String(owned.entry.baseline_last_message_id));
      if (anchorIndex < 0 || ordered.indexOf(confirmedId) <= anchorIndex) return { ok: false, code: "DOT_CONFIRMATION_NOT_AFTER_ANCHOR" };
      if (String(message.confirmation_identity_key || "") !== owned.key) return { ok: false, code: "CONVERSATION_MISMATCH" };
    }
    const next = await putOutbox(owned.key, {
      ...owned.entry,
      phase: "committed",
      committed_at: nowIso(),
      attachment_confirmed_at: nowIso(),
      confirmation_message_id: message.confirmation_message_id || null,
      confirmation_ordered_message_ids: isDotKey(owned.key) ? message.confirmation_ordered_message_ids.map(String) : owned.entry.confirmation_ordered_message_ids
    });
    return { ok: true, outbox: next };
  }

  async function readDotReceipts() {
    const value = (await storageGet(DOT_COMPLETION_RECEIPTS_KEY))[DOT_COMPLETION_RECEIPTS_KEY];
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }

  async function saveDotCompletionReceipt(key, entry, message) {
    const deliveryId = String(entry?.delivery_id || "");
    const confirmationId = String(message?.confirmation_message_id || "");
    if (!deliveryId || !confirmationId || entry?.phase !== "committed" || String(entry.confirmation_message_id || "") !== confirmationId || String(message?.confirmation_basis || "") !== "dot_attachment_match") {
      return { ok: false, code: "DOT_COMPLETION_RECEIPT_EVIDENCE_INVALID" };
    }
    if (entry.type === "manual" && !String(entry.operation_id || "")) return { ok: false, code: "DOT_COMPLETION_RECEIPT_OPERATION_MISSING" };
    const bucket = await readDotReceipts();
    const deliveries = bucket[key] && typeof bucket[key] === "object" && !Array.isArray(bucket[key]) ? { ...bucket[key] } : {};
    const existing = deliveries[deliveryId];
    if (existing && (existing.conversation_key !== key || existing.delivery_id !== deliveryId || existing.confirmation_message_id !== confirmationId || existing.operation_id !== (entry.operation_id || null))) {
      return { ok: false, code: "DOT_COMPLETION_RECEIPT_CONFLICT" };
    }
    deliveries[deliveryId] = existing || {
      conversation_key: key,
      delivery_id: deliveryId,
      operation_id: entry.operation_id ? String(entry.operation_id) : null,
      type: String(entry.type || ""),
      tab_id: Number(entry.tab_id),
      confirmation_message_id: confirmationId,
      confirmation_basis: "dot_attachment_match",
      report_prefix_applied: entry.report_prefix_applied === true,
      artifact_descriptors: (Array.isArray(entry.artifact_descriptors) ? entry.artifact_descriptors : []).map((item) => ({ artifact_key: String(item?.artifact_key || ""), chunk_count: Number(item?.chunk_count || 0) })).filter((item) => item.artifact_key),
      receipt_created_at: nowIso()
    };
    await storageSet({ [DOT_COMPLETION_RECEIPTS_KEY]: { ...bucket, [key]: deliveries } });
    return { ok: true, receipt: deliveries[deliveryId] };
  }

  async function dotManualOperationMatchesEntry(key, entry, sender) {
    if (entry?.type !== "manual") return true;
    const operationId = String(entry?.operation_id || "");
    const deliveryId = String(entry?.delivery_id || "");
    const senderTabId = Number(sender?.tab?.id);
    if (!operationId || !deliveryId || !Number.isInteger(senderTabId)) return false;
    const map = (await storageGet(KEYS.MANUAL_OPERATIONS))[KEYS.MANUAL_OPERATIONS] || {};
    const operation = map[key] || null;
    if (!operation || String(operation.operation_id || "") !== operationId || String(operation.delivery_id || "") !== deliveryId || Number(operation.tab_id) !== senderTabId || Number(entry.tab_id) !== senderTabId) return false;
    if (operation.status === "delivering") return true;
    return operation.status === "completed" && operation.delivery_confirmed === true && operation.confirmation_basis === "dot_attachment_match";
  }

  async function removeDotCompletionReceipt(key, deliveryId) {
    const bucket = await readDotReceipts();
    const deliveries = bucket[key] && typeof bucket[key] === "object" && !Array.isArray(bucket[key]) ? { ...bucket[key] } : {};
    delete deliveries[deliveryId];
    const next = { ...bucket };
    if (Object.keys(deliveries).length) next[key] = deliveries;
    else delete next[key];
    await storageSet({ [DOT_COMPLETION_RECEIPTS_KEY]: next });
  }

  async function markDotCompletionReceiptCompleted(key, receipt) {
    const bucket = await readDotReceipts();
    const deliveries = bucket[key] && typeof bucket[key] === "object" && !Array.isArray(bucket[key]) ? { ...bucket[key] } : {};
    const deliveryId = String(receipt?.delivery_id || "");
    const current = deliveries[deliveryId];
    if (!current || current.conversation_key !== key || current.confirmation_message_id !== receipt.confirmation_message_id) return false;
    deliveries[deliveryId] = { ...current, status: "completed", completed_at: current.completed_at || nowIso(), artifact_descriptors: [] };
    const completed = Object.entries(deliveries).filter(([, item]) => item?.status === "completed").sort((a, b) => String(a[1].completed_at || "").localeCompare(String(b[1].completed_at || "")));
    for (const [oldId] of completed.slice(0, Math.max(0, completed.length - 20))) delete deliveries[oldId];
    await storageSet({ [DOT_COMPLETION_RECEIPTS_KEY]: { ...bucket, [key]: deliveries } });
    return true;
  }

  async function completedManualOperationMatchesReceipt(key, receipt) {
    if (!receipt.operation_id) return receipt.type !== "manual";
    const map = (await storageGet(KEYS.MANUAL_OPERATIONS))[KEYS.MANUAL_OPERATIONS] || {};
    const operation = map[key] || null;
    return Boolean(operation && String(operation.operation_id || "") === String(receipt.operation_id) &&
      String(operation.delivery_id || "") === String(receipt.delivery_id) && operation.status === "completed" &&
      operation.delivery_confirmed === true && operation.confirmation_basis === "dot_attachment_match");
  }

  async function reconcileDotCompletionReceipts(conversationKey, requestedTabId, sender = null) {
    const key = normalizeConversationKey(conversationKey);
    if (!isDotKey(key)) return [];
    const bucket = await readDotReceipts();
    const deliveries = bucket[key] && typeof bucket[key] === "object" && !Array.isArray(bucket[key]) ? bucket[key] : {};
    const results = [];
    for (const receipt of Object.values(deliveries)) {
      const deliveryId = String(receipt?.delivery_id || "");
      const ownerTabId = Number(receipt?.tab_id);
      if (!deliveryId || receipt?.conversation_key !== key || !Number.isInteger(ownerTabId) || Number(requestedTabId) !== ownerTabId) continue;
      if (sender?.tab?.id != null && Number(sender.tab.id) !== ownerTabId) continue;
      try { await assertTabConversation(ownerTabId, key); } catch { continue; }
      if (receipt.status === "completed") continue;

      let live = await getConversationOutbox(key);
      if (live && String(live.delivery_id || "") !== deliveryId) {
        // A different owner/operation has moved forward. Do not clear or rewrite
        // its outbox. A completed receipt may still release only its own artifact.
        if (receipt.type === "manual" && !(await completedManualOperationMatchesReceipt(key, receipt))) continue;
      } else if (live) {
        if (sender?.tab?.id == null || Number(sender.tab.id) !== ownerTabId) continue;
        if (live.phase !== "committed" || String(live.confirmation_message_id || "") !== String(receipt.confirmation_message_id || "") || String(live.operation_id || "") !== String(receipt.operation_id || "")) continue;
        if (live.type === "manual") {
          const opMap = (await storageGet(KEYS.MANUAL_OPERATIONS))[KEYS.MANUAL_OPERATIONS] || {};
          const operation = opMap[key] || null;
          if (!operation || String(operation.operation_id || "") !== String(receipt.operation_id || "") || String(operation.delivery_id || "") !== deliveryId) continue;
        }
        const replay = await baseHandleMessage({
          type: receipt.type === "autorun" ? "WS_AUTO_DELIVERY_COMPLETE" : "WS_MANUAL_DELIVERY_COMPLETE",
          conversation_key: key,
          delivery_id: deliveryId,
          confirmation_basis: "dot_attachment_match",
          confirmation_message_id: receipt.confirmation_message_id
        }, sender);
        if (!replay?.ok) continue;
        live = await getConversationOutbox(key);
      }

      if (receipt.type === "manual" && !(await completedManualOperationMatchesReceipt(key, receipt))) {
        const opData = await storageGet(KEYS.MANUAL_OPERATIONS);
        const opMap = { ...(opData[KEYS.MANUAL_OPERATIONS] || {}) };
        const operation = opMap[key] || null;
        if (!operation || String(operation.operation_id || "") !== String(receipt.operation_id || "") || String(operation.delivery_id || "") !== deliveryId || operation.status !== "delivering") continue;
        opMap[key] = {
          ...operation,
          status: "completed",
          delivery_confirmed: true,
          confirmation_basis: "dot_attachment_match",
          completed_at: operation.completed_at || nowIso()
        };
        await storageSet({ [KEYS.MANUAL_OPERATIONS]: opMap });
      }

      if (["manual", "autorun"].includes(String(receipt.type || ""))) {
        await noteConfirmedReportPrefix(key, receipt.report_prefix_applied === true, deliveryId);
      }
      await YMBFileArtifactStore.cleanupDescriptors(receipt.artifact_descriptors || []).catch(() => null);
      live = await getConversationOutbox(key);
      if (!live) await promotePendingContentError(key);
      await markDotCompletionReceiptCompleted(key, receipt);
      results.push(deliveryId);
    }
    return results;
  }

  async function setAttachmentPause(message, sender) {
    if (typeof message.paused !== "boolean") return { ok: false, code: "ATTACHMENT_PAUSE_VALUE_REQUIRED" };
    const owned = await ownedAttachment(message, sender, true);
    if (owned.error) return owned.error;
    if ([SEND_COMMITTED_PHASE, "committed"].includes(owned.entry.phase)) return { ok: false, code: "ATTACHMENT_SEND_ALREADY_COMMITTED", request_executed: false };
    if (!["claimed", "attachment_committed", "attachment_ready"].includes(owned.entry.phase)) return { ok: false, code: "ATTACHMENT_PHASE_INVALID" };
    if ((owned.entry.delivery_paused === true) !== message.paused) await putOutbox(owned.key, { ...owned.entry, delivery_paused: message.paused, delivery_pause_updated_at: nowIso() });
    return { ok: true, paused: message.paused, delivery_id: owned.entry.delivery_id, phase: owned.entry.phase, request_executed: false, evidence_retained: true };
  }

  async function confirmedDotCompletionExists(key, message, senderTabId) {
    const deliveryId = String(message?.delivery_id || "");
    const ownerTabId = Number(senderTabId);
    if (!deliveryId || !Number.isInteger(ownerTabId) || String(message?.confirmation_basis || "") !== "dot_attachment_match" || !String(message?.confirmation_message_id || "")) return false;
    if (message?.type === "WS_MANUAL_DELIVERY_COMPLETE") {
      const map = (await storageGet(KEYS.MANUAL_OPERATIONS))[KEYS.MANUAL_OPERATIONS] || {};
      const operation = map[key] || null;
      const receipt = (await readDotReceipts())[key]?.[deliveryId] || null;
      const completedOperation = operation?.status === "completed" && operation?.delivery_confirmed === true && operation?.confirmation_basis === "dot_attachment_match" && String(operation.delivery_id || "") === deliveryId && Number(operation.tab_id) === ownerTabId;
      const completedReceipt = receipt?.status === "completed" && receipt?.conversation_key === key && ["manual", "content_error"].includes(String(receipt.type || "")) &&
        String(receipt.confirmation_message_id || "") === String(message.confirmation_message_id || "") && Number(receipt.tab_id) === ownerTabId &&
        (receipt.type !== "manual" || Boolean(String(receipt.operation_id || "")));
      if (!(completedOperation || completedReceipt)) return false;
      try { await assertTabConversation(ownerTabId, key); return true; } catch { return false; }
    }
    if (message?.type === "WS_AUTO_DELIVERY_COMPLETE") {
      const run = await getAutoRun(key);
      if (!(String(run?.delivery?.delivery_id || "") === deliveryId && run?.delivery?.phase === "confirmed" && Number(run.tab_id) === ownerTabId)) return false;
      try { await assertTabConversation(ownerTabId, key); return true; } catch { return false; }
    }
    return false;
  }

  handleMessage = async function fileAwareHandleMessage(message, sender) {
    switch (message?.type) {
      case "WS_GET_OUTBOX_ARTIFACT_CHUNK": return attachmentChunk(message, sender);
      case "WS_MARK_ATTACHMENT_COMMITTED": return serializeMutation(() => markAttachmentCommitted(message, sender));
      case "WS_MARK_ATTACHMENT_READY": return serializeMutation(() => markAttachmentReady(message, sender));
      case "WS_COMMIT_ATTACHMENT_SEND": return serializeMutation(() => commitAttachmentSend(message, sender));
      case "WS_MARK_ATTACHMENT_CLICK_DISPATCHED": return serializeMutation(() => markAttachmentClickDispatched(message, sender));
      case "WS_ROLLBACK_ATTACHMENT_SEND": return serializeMutation(() => rollbackAttachmentSend(message, sender));
      case "WS_CONFIRM_ATTACHMENT_SEND": return serializeMutation(() => confirmAttachmentSend(message, sender));
      case "WS_SET_ATTACHMENT_PAUSED": return serializeMutation(() => setAttachmentPause(message, sender));
      case "WS_MANUAL_DELIVERY_COMPLETE": case "WS_AUTO_DELIVERY_COMPLETE": {
        const key = normalizeConversationKey(message.conversation_key);
        if (isDotKey(key)) return serializeMutation(async () => {
          const entry = await getConversationOutbox(key);
          if (!entry || String(entry.delivery_id || "") !== String(message.delivery_id || "")) {
            await reconcileDotCompletionReceipts(key, sender?.tab?.id, sender);
            return await confirmedDotCompletionExists(key, message, sender?.tab?.id) ? { ok: true, duplicate: true } : { ok: false, code: "DELIVERY_NOT_FOUND" };
          }
          if (entry.delivery_mode !== DELIVERY_MODE) return { ok: false, code: "DOT_ATTACHMENT_CONFIRMATION_REQUIRED", request_executed: false };
          if (entry.delivery_paused === true) return { ok: false, code: "ATTACHMENT_DELIVERY_PAUSED", request_executed: false };
          if (entry.phase !== "committed" || !entry.confirmation_message_id || String(message.confirmation_message_id || "") !== String(entry.confirmation_message_id) || String(message.confirmation_basis || "") !== "dot_attachment_match") return { ok: false, code: "DOT_ATTACHMENT_CONFIRMATION_REQUIRED", request_executed: false };
          const ownerFence = await outboxOwnerFence(entry, key, sender);
          if (ownerFence) return ownerFence;
          if (!(await dotManualOperationMatchesEntry(key, entry, sender))) return { ok: false, code: "DOT_COMPLETION_OPERATION_MISMATCH", request_executed: false };
          const receiptResult = await saveDotCompletionReceipt(key, entry, message);
          if (!receiptResult.ok) return receiptResult;
          const completed = await baseHandleMessage(message, sender);
          if (completed?.ok) await reconcileDotCompletionReceipts(key, sender?.tab?.id, sender);
          return completed;
        });
        const before = await getConversationOutbox(key);
        if (before?.delivery_mode === DELIVERY_MODE && before.delivery_paused === true) return { ok: false, code: "ATTACHMENT_DELIVERY_PAUSED", request_executed: false };
        return baseHandleMessage(message, sender);
      }
      case "WS_MARK_DELIVERY_COMMITTED": {
        const entry = await getConversationOutbox(message.conversation_key);
        if (entry?.delivery_mode === DELIVERY_MODE) return { ok: false, code: "ATTACHMENT_SEND_PATH_REQUIRED", request_executed: false };
        return baseHandleMessage(message, sender);
      }
      case "WS_GET_OUTBOX": {
        const key = normalizeConversationKey(message?.conversation_key);
        if (isDotKey(key)) await reconcileDotCompletionReceipts(key, sender?.tab?.id ?? message?.tab_id, sender);
        const response = await baseHandleMessage(message, sender);
        const entry = response?.outbox;
        if (!response?.ok || !entry || !isDotKey(key) || entry.phase !== "claimed" || !String(entry.report_text || "") || (Array.isArray(entry.artifact_descriptors) && entry.artifact_descriptors.length)) return response;
        return serializeMutation(async () => {
          const fresh = await getConversationOutbox(key);
          if (!fresh || String(fresh.delivery_id || "") !== String(entry.delivery_id || "") || fresh.phase !== "claimed") return { ok: true, outbox: fresh || null };
          if (Array.isArray(fresh.artifact_descriptors) && fresh.artifact_descriptors.length) return { ok: true, outbox: fresh };
          const ownerFence = await outboxOwnerFence(fresh, key, sender);
          if (ownerFence) return ownerFence;
          const prepared = await prepareEntry(fresh, key);
          if (prepared.delivery_mode !== DELIVERY_MODE || !prepared.artifact_descriptors?.length) return { ok: true, outbox: fresh };
          const latest = await getConversationOutbox(key);
          if (!latest || String(latest.delivery_id || "") !== String(fresh.delivery_id || "") || latest.phase !== "claimed" || (Array.isArray(latest.artifact_descriptors) && latest.artifact_descriptors.length)) {
            await YMBFileArtifactStore.cleanupDescriptors(prepared.artifact_descriptors).catch(() => null);
            return { ok: true, outbox: latest || null };
          }
          const stored = await putOutbox(key, prepared);
          const verified = await getConversationOutbox(key);
          if (!verified || String(verified.delivery_id || "") !== String(fresh.delivery_id || "") || verified.phase !== "claimed" || verified.delivery_mode !== DELIVERY_MODE) return { ok: true, outbox: verified || null };
          return { ok: true, outbox: stored };
        });
      }
      case "WS_GET_STATE": case "WS_EXECUTE_MANUAL_BLOCK": case "WS_SET_MANUAL_MODE": {
        const rawKey = message?.conversation_key;
        if (rawKey && isDotKey(rawKey)) {
          const key = normalizeConversationKey(rawKey);
          return serializeMutation(async () => {
            await reconcileDotCompletionReceipts(key, sender?.tab?.id ?? message?.tab_id, sender);
            return baseHandleMessage(message, sender);
          });
        }
        return baseHandleMessage(message, sender);
      }
      default: return baseHandleMessage(message, sender);
    }
  };

  void YMBFileArtifactStore.cleanupExpired().catch(() => null);

  globalThis.YMBFileDeliveryWorkerTransport = Object.freeze({ DELIVERY_MODE, CHATGPT_FILE_TEXT_THRESHOLD, SEND_COMMITTED_PHASE, compactLargeCommandResult });
})();
