import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { createHash, webcrypto } from "node:crypto";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dotUuid = "6a82924e-5ed0-83eb-84a2-851ddad40c88";
const otherUuid = "01a0f082-2d5a-74e1-9fcd-2b2ad2bd30d2";
const dotKey = `https://chatgpt.com|dots:${dotUuid}`;
const tabId = 53;

function makeEvent() {
  const listeners = [];
  return {
    listeners,
    addListener(listener) { listeners.push(listener); },
    removeListener(listener) { const index = listeners.indexOf(listener); if (index >= 0) listeners.splice(index, 1); },
    fire(...args) { for (const listener of [...listeners]) listener(...args); }
  };
}

function makeMemoryIndexedDB() {
  const databases = new Map();
  function transactionFactory(db) {
    const tx = {
      error: null, oncomplete: null, onabort: null, onerror: null,
      pending: 0, completionQueued: false,
      objectStore(name) { return storeApi(db, tx, name); },
      abort() { this.onabort?.(); }
    };
    tx.enqueue = (work) => {
      const request = { result: undefined, error: null, onsuccess: null, onerror: null };
      tx.pending += 1;
      queueMicrotask(() => {
        try {
          request.result = work();
          request.onsuccess?.();
        } catch (error) {
          request.error = error;
          tx.error = error;
          request.onerror?.();
          tx.onabort?.();
          return;
        }
        tx.pending -= 1;
        if (tx.pending === 0 && !tx.completionQueued) {
          tx.completionQueued = true;
          queueMicrotask(() => { if (tx.pending === 0) tx.oncomplete?.(); else tx.completionQueued = false; });
        }
      });
      return request;
    };
    return tx;
  }
  function storeApi(db, tx, name) {
    const store = db.stores.get(name);
    if (!store) throw new Error(`Missing IDB store ${name}`);
    const api = {
      indexNames: { contains(indexName) { return store.indexes.has(indexName); } },
      createIndex(indexName, keyPath) { store.indexes.set(indexName, keyPath); },
      put(record) {
        const copy = structuredClone(record);
        return tx.enqueue(() => { const key = String(copy[store.keyPath]); store.records.set(key, copy); return key; });
      },
      get(key) { return tx.enqueue(() => structuredClone(store.records.get(String(key)))); },
      getAll() { return tx.enqueue(() => [...store.records.values()].map((record) => structuredClone(record))); },
      delete(key) { return tx.enqueue(() => store.records.delete(String(key))); },
      index(indexName) {
        const keyPath = store.indexes.get(indexName);
        if (!keyPath) throw new Error(`Missing IDB index ${indexName}`);
        return {
          openKeyCursor(range) {
            const value = String(range?.value ?? "");
            const keys = [...store.records.entries()].filter(([, record]) => String(record?.[keyPath] ?? "") === value).map(([key]) => key);
            let cursorIndex = 0;
            const enqueueCursor = () => tx.enqueue(() => {
              if (cursorIndex >= keys.length) return null;
              const primaryKey = keys[cursorIndex];
              return { primaryKey, continue() { cursorIndex += 1; enqueueCursor(); } };
            });
            return enqueueCursor();
          }
        };
      }
    };
    return api;
  }
  function makeDb(name, version) {
    const db = {
      name, version, stores: new Map(),
      objectStoreNames: { contains(storeName) { return db.stores.has(storeName); } },
      createObjectStore(storeName, options = {}) {
        if (!db.stores.has(storeName)) db.stores.set(storeName, { keyPath: options.keyPath || "id", records: new Map(), indexes: new Map() });
        return storeApi(db, transactionFactory(db), storeName);
      },
      transaction() { return transactionFactory(db); },
      close() {}
    };
    return db;
  }
  return {
    open(name, version) {
      const request = { result: null, transaction: null, onupgradeneeded: null, onsuccess: null, onerror: null, onblocked: null };
      queueMicrotask(() => {
        let db = databases.get(name);
        const fresh = !db;
        if (!db) { db = makeDb(name, version); databases.set(name, db); }
        request.result = db;
        if (fresh || version > Number(db.version || 0)) {
          db.version = version;
          request.transaction = transactionFactory(db);
          request.onupgradeneeded?.();
        }
        request.onsuccess?.();
      });
      return request;
    }
  };
}

function identityForUrl(url) {
  const parsed = new URL(url);
  const dot = parsed.origin === "https://chatgpt.com" && parsed.pathname.match(/^\/dots\/([0-9a-f-]{36})\/?$/i);
  const chat = parsed.pathname.match(/(?:^|\/)c\/([0-9a-f-]{36})(?:\/|$)/i);
  const id = dot ? `dots:${dot[1].toLowerCase()}` : chat?.[1]?.toLowerCase() || "";
  const identity = {
    origin: parsed.origin,
    conversation_id: id,
    conversation_key: id ? `${parsed.origin}|${id}` : "",
    status: id ? "confirmed" : "unconfirmed",
    source: "path",
    chat_path: dot ? `/dots/${dot[1].toLowerCase()}` : chat ? `/c/${chat[1].toLowerCase()}` : parsed.pathname
  };
  return { ok: Boolean(id), identity, conversation_key: identity.conversation_key };
}

function createWorker(options = {}) {
  const storageChanged = makeEvent();
  const runtimeMessage = makeEvent();
  const runtimeConnect = makeEvent();
  const storage = options.storage || Object.create(null);
  const indexedDB = options.indexedDB || makeMemoryIndexedDB();
  const failNextStorageKeys = new Set();
  const failStorageSetCounts = new Map();
  let currentUrl = `https://chatgpt.com/dots/${dotUuid}`;
  let providerCalls = 0;
  const local = {
    async get(keys) {
      if (keys == null) return { ...storage };
      if (typeof keys === "string") return { [keys]: storage[keys] };
      if (Array.isArray(keys)) return Object.fromEntries(keys.map((key) => [key, storage[key]]));
      return Object.fromEntries(Object.entries(keys).map(([key, fallback]) => [key, storage[key] === undefined ? fallback : storage[key]]));
    },
    async set(entries) {
      for (const key of failNextStorageKeys) {
        if (Object.hasOwn(entries || {}, key)) { failNextStorageKeys.delete(key); throw Object.assign(new Error(`injected storage failure: ${key}`), { code: "INJECTED_STORAGE_FAILURE" }); }
      }
      for (const [key, remaining] of failStorageSetCounts) {
        if (!Object.hasOwn(entries || {}, key)) continue;
        if (remaining <= 0) { failStorageSetCounts.delete(key); throw Object.assign(new Error(`injected storage failure: ${key}`), { code: "INJECTED_STORAGE_FAILURE" }); }
        failStorageSetCounts.set(key, remaining - 1);
      }
      const changes = {};
      for (const [key, value] of Object.entries(entries || {})) {
        const oldValue = storage[key]; storage[key] = structuredClone(value); changes[key] = { oldValue, newValue: storage[key] };
      }
      if (Object.keys(changes).length) storageChanged.fire(changes, "local");
    },
    async remove(keys) { for (const key of Array.isArray(keys) ? keys : [keys]) delete storage[key]; }
  };
  const chrome = {
    runtime: { id: "test-extension-id", lastError: null, getManifest: () => ({ version: "0.1.10" }), onMessage: runtimeMessage, onConnect: runtimeConnect },
    storage: { onChanged: storageChanged, local },
    tabs: {
      async get(id) { return { id, url: currentUrl }; },
      sendMessage(id, message, callback) {
        const response = message?.type === "WS_GET_IDENTITY" ? identityForUrl(currentUrl) : { ok: true };
        callback?.(response);
        return Promise.resolve(response);
      }
    }
  };
  const context = vm.createContext({
    chrome, crypto: webcrypto, TextEncoder, TextDecoder, URL, Blob, File: globalThis.File,
    AbortController, setTimeout, clearTimeout, setInterval, clearInterval, queueMicrotask,
    structuredClone, console, Buffer, Intl, Math, Date, performance,
    indexedDB, IDBKeyRange: { only(value) { return { value }; } },
    atob: (value) => Buffer.from(value, "base64").toString("binary"),
    btoa: (value) => Buffer.from(value, "binary").toString("base64"),
    fetch: async () => { providerCalls += 1; throw new Error("Provider fetch is forbidden in this test."); }
  });
  context.importScripts = (...files) => {
    for (const file of files) vm.runInContext(fs.readFileSync(path.join(root, file), "utf8"), context, { filename: file });
  };
  vm.runInContext(fs.readFileSync(path.join(root, "phase3_service_worker_bootstrap.js"), "utf8"), context, { filename: "phase3_service_worker_bootstrap.js" });
  return {
    context,
    storage,
    indexedDB,
    setUrl(url) { currentUrl = url; },
    failNextStorageSet(key) { failNextStorageKeys.add(String(key)); },
    failStorageSetAfter(key, successfulWrites = 0) { failStorageSetCounts.set(String(key), Math.max(0, Math.trunc(Number(successfulWrites) || 0))); },
    getProviderCalls() { return providerCalls; },
    async send(message, sender = {}) { return await context.handleMessage(message, sender); }
  };
}

async function prepareCommittedManualAttachment(worker, suffix = "prepared") {
  const { context } = worker;
  const owner = { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } };
  await worker.send({ type: "WS_BIND_CONVERSATION", tab_id: tabId });
  await worker.send({ type: "WS_SET_MANUAL_MODE", conversation_key: dotKey, enabled: true, tab_id: tabId });
  const operation = await worker.send({ type: "WS_EXECUTE_MANUAL_BLOCK", conversation_key: dotKey, block_text: `synthetic unsupported ${suffix}`, manual_request_token: `manual-${suffix}` }, owner);
  const entry = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, owner)).outbox;
  const descriptor = entry.artifact_descriptors[0];
  const baseline = { baseline_message_ids: [`u-${suffix}`, `a-${suffix}`], baseline_self_message_ids: [`u-${suffix}`], baseline_last_message_id: `a-${suffix}`, baseline_captured: true, baseline_identity_key: dotKey };
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_COMMITTED", conversation_key: dotKey, delivery_id: entry.delivery_id, ...baseline }, owner)).ok, true);
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_READY", conversation_key: dotKey, delivery_id: entry.delivery_id, attached_filenames: [descriptor.filename] }, owner)).ok, true);
  const caption = `Yandex Marketing Bridge: результат прикреплён файлом ${descriptor.filename}.`;
  assert.equal((await worker.send({ type: "WS_COMMIT_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id, send_marker: caption, expected_attachment_names: [descriptor.filename] }, owner)).ok, true);
  const confirmationId = `u-confirmed-${suffix}`;
  assert.equal((await worker.send({ type: "WS_CONFIRM_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id, confirmation_message_id: confirmationId, confirmation_identity_key: dotKey, confirmation_ordered_message_ids: [...baseline.baseline_message_ids, confirmationId] }, owner)).ok, true);
  return { owner, entry, descriptor, operation, confirmationId, completion: { type: "WS_MANUAL_DELIVERY_COMPLETE", conversation_key: dotKey, delivery_id: entry.delivery_id, confirmation_basis: "dot_attachment_match", confirmation_message_id: confirmationId } };
}

class DOMElement {
  constructor(tag, attrs = {}, text = "") {
    this.tagName = String(tag).toUpperCase(); this.attrs = { ...attrs }; this.style = {};
    this.children = []; this.parentElement = null; this.isConnected = true; this._text = String(text);
    this.rect = { left: 0, top: 0, right: 24, bottom: 20, width: 24, height: 20 };
    this.selectors = new Map(); this.listeners = new Map(); this.disabled = false; this.files = []; this.dataset = {}; this.shadowRoot = null;
    this.classList = { contains: (name) => String(this.attrs.class || "").split(/\s+/).includes(name), [Symbol.iterator]: function* () { yield* String(this.owner.attrs.class || "").split(/\s+/).filter(Boolean); }, owner: this };
  }
  get textContent() { return this._text; }
  set textContent(value) { this._text = String(value ?? ""); }
  get innerText() { return this._text; }
  set innerText(value) { this._text = String(value ?? ""); }
  get type() { return this.getAttribute("type") || ""; }
  set type(value) { this.attrs.type = String(value); }
  get id() { return this.getAttribute("id") || ""; }
  set id(value) { this.attrs.id = String(value); }
  get className() { return this.getAttribute("class") || ""; }
  set className(value) { this.attrs.class = String(value); }
  getAttribute(name) { return Object.hasOwn(this.attrs, name) ? String(this.attrs[name]) : null; }
  setAttribute(name, value) { this.attrs[name] = String(value); }
  hasAttribute(name) { return Object.hasOwn(this.attrs, name); }
  append(...items) { for (const item of items) { this.children.push(item); item.parentElement = this; item.isConnected = this.isConnected; } }
  appendChild(item) { this.append(item); return item; }
  attachShadow() { this.shadowRoot = new DOMElement("shadow-root"); this.shadowRoot.host = this; return this.shadowRoot; }
  replaceChildren(...items) { for (const old of this.children) old.isConnected = false; this.children = []; this.append(...items); }
  remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter((child) => child !== this); this.parentElement = null; this.isConnected = false; }
  setSelector(selector, values) { this.selectors.set(selector, [...values]); }
  querySelectorAll(selector) { return [...(this.selectors.get(selector) || [])]; }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  matches(selector) {
    if (selector === "article.message-row") return this.tagName === "ARTICLE" && this.classList.contains("message-row");
    if (selector === "article.message-row.self[data-message-id]") return this.tagName === "ARTICLE" && this.classList.contains("message-row") && this.classList.contains("self") && Boolean(this.getAttribute("data-message-id"));
    if (selector === '[data-orbit-message-block="codeBlock"]') return this.getAttribute("data-orbit-message-block") === "codeBlock";
    if (selector === '[aria-busy="true"]') return this.getAttribute("aria-busy") === "true";
    return false;
  }
  closest(selector) {
    for (let node = this; node; node = node.parentElement) {
      if (selector === '[data-orbit-message-parts="true"]' && node.getAttribute("data-orbit-message-parts") === "true") return node;
      if (selector === '[data-orbit-message-block="codeBlock"]' && node.matches(selector)) return node;
      if (selector === "article.message-row[data-message-id]" && node.tagName === "ARTICLE" && node.classList.contains("message-row") && node.getAttribute("data-message-id")) return node;
    }
    return null;
  }
  contains(other) { return this === other || this.children.some((child) => child.contains(other)); }
  getBoundingClientRect() { return this.rect; }
  addEventListener(type, listener, capture = false) { const list = this.listeners.get(type) || []; list.push({ listener, capture: Boolean(capture) }); this.listeners.set(type, list); }
  removeEventListener(type, listener, capture = false) { this.listeners.set(type, (this.listeners.get(type) || []).filter((item) => item.listener !== listener || item.capture !== Boolean(capture))); }
  dispatchEvent(event) { event.target ||= this; for (const item of [...(this.listeners.get(event.type) || [])]) item.listener(event); return !event.defaultPrevented; }
  click() { this.nativeClickCount = (this.nativeClickCount || 0) + 1; this.onNativeClick?.(); }
}
class DOMInput extends DOMElement { constructor(attrs = {}) { super("input", attrs); this.files = []; } dispatchEvent(event) { const result = super.dispatchEvent(event); this.onDispatch?.(event); return result; } }
class DOMButton extends DOMElement { constructor(attrs = {}, text = "") { super("button", attrs, text); } }
class FakeDataTransfer { constructor() { this.items = { files: [], add: (file) => this.items.files.push(file) }; } get files() { return this.items.files; } }
class FakeInputEvent { constructor(type, init = {}) { this.type = type; this.bubbles = init.bubbles === true; this.defaultPrevented = false; } }

function makeResourceCard(filename) {
  const card = new DOMElement("div", { class: "group/resource-card relative inline-flex" });
  const open = new DOMButton({ type: "button", "aria-label": `Открыть ${filename}`, "aria-busy": "false" });
  const wrap = new DOMElement("div", { class: "pointer-events-none relative flex" });
  const svg = new DOMElement("svg"); const pathNode = new DOMElement("path"); svg.append(pathNode);
  const label = new DOMElement("span", { title: filename, class: "truncate" }, filename);
  wrap.append(svg, label); card.append(open, wrap);
  card.setSelector('button[aria-label^="Открыть "][type="button"]', [open]); card.setSelector("span[title]", [label]);
  wrap.setSelector("*", [svg, pathNode, label]);
  return card;
}

function buildContentDOM() {
  const rows = [];
  const oldFileOnly = new DOMElement("article", { class: "message-row self", "data-message-id": "u-old-file-only" });
  const oldList = new DOMElement("div", { class: "attachment-list" }); const oldSurface = new DOMElement("div", { class: "message-surface" }); oldSurface.append(makeResourceCard("old.pdf")); oldList.append(oldSurface);
  oldFileOnly.setSelector(".message-text[data-content-search-unit-key]", []); oldFileOnly.setSelector(".attachment-list", [oldList]); oldFileOnly.append(oldList);
  rows.push(oldFileOnly);
  const anchor = new DOMElement("article", { class: "message-row", "data-message-id": "a-anchor" }); rows.push(anchor);

  const textbox = new DOMElement("div", { "data-composer-markdown": "", contenteditable: "true", role: "textbox", "aria-label": "Сообщение" });
  const send = new DOMButton({ "aria-label": "Отправить" });
  const footer = new DOMElement("div", { "data-composer-footer-responsive": "true" }); footer.append(textbox, send);
  footer.setSelector('div[data-composer-markdown][contenteditable="true"][role="textbox"][aria-label="Сообщение"]', [textbox]); footer.setSelector('button[aria-label="Отправить"]', [send]);

  const fileInput = new DOMInput({ type: "file", "data-role": "file-input", multiple: "" });
  const attachmentRow = new DOMElement("div", { "data-composer-attachments-row": "true" });
  const attachments = new DOMElement("div", { "data-composer-attachments": "true" }); attachments.append(attachmentRow); attachments.setSelector('[data-composer-attachments-row="true"]', [attachmentRow]);
  const composerRoot = new DOMElement("div", { "data-role": "composer" }); composerRoot.append(footer, attachments, fileInput);
  composerRoot.setSelector('input[type="file"][data-role="file-input"][multiple]', [fileInput]); composerRoot.setSelector("[data-composer-attachments]", [attachments]);
  let attachDispatches = 0;
  function refreshComposerFiles() {
    attachmentRow.replaceChildren(...fileInput.files.map((file) => {
      const card = new DOMElement("div", { class: "group/composer-attachment" });
      const name = new DOMElement("span", { class: "truncate" }, file.name);
      const remove = new DOMButton({ "aria-label": `Удалить ${file.name}` }); card.append(name, remove);
      card.setSelector("span.truncate", [name]); card.setSelector("button[aria-label]", [remove]);
      return card;
    }));
    attachments.textContent = fileInput.files.map((file) => file.name).join(" ");
  }
  fileInput.onDispatch = (event) => { if (["input", "change"].includes(event.type)) refreshComposerFiles(); if (event.type === "change") attachDispatches += 1; };

  function sentRow(id, caption, filename) {
    const row = new DOMElement("article", { class: "message-row self", "data-message-id": id });
    const text = new DOMElement("div", { class: "message-text", "data-content-search-unit-key": `${id}:message` }, caption);
    const list = new DOMElement("div", { class: "attachment-list" }); const surface = new DOMElement("div", { class: "message-surface" }); surface.append(makeResourceCard(filename)); list.append(surface);
    row.setSelector(".message-text[data-content-search-unit-key]", [text]); row.setSelector(".attachment-list", [list]); row.append(text, list);
    return row;
  }
  const body = new DOMElement("body"); const html = new DOMElement("html"); html.append(body); body.append(composerRoot);
  const document = {
    documentElement: html, body,
    querySelector(selector) { if (selector === 'link[rel="canonical"]') return null; return null; },
    querySelectorAll(selector) {
      if (selector === "article.message-row") return [...rows];
      if (selector === "article.message-row.self[data-message-id]") return rows.filter((row) => row.classList.contains("self"));
      if (selector === "[data-composer-footer-responsive]") return [footer];
      if (selector === '[data-role="composer"]') return [composerRoot];
      return [];
    },
    createElement(tag) { return tag.toLowerCase() === "button" ? new DOMButton() : new DOMElement(tag); },
    getElementById(id) { return findById(html, id); },
    addEventListener() {}, removeEventListener() {}
  };
  function findById(node, id) { if (node.getAttribute("id") === id) return node; for (const child of node.children) { const found = findById(child, id); if (found) return found; } return null; }
  send.onNativeClick = () => {
    const caption = textbox.textContent;
    const filename = String(fileInput.files[0]?.name || "");
    rows.push(sentRow("u-sent", caption, filename));
    textbox.textContent = "";
  };
  return { document, rows, oldFileOnly, anchor, textbox, send, footer, fileInput, attachmentRow, attachments, composerRoot, getAttachDispatches: () => attachDispatches };
}

function createContentContext(worker, dom, href = `https://chatgpt.com/dots/${dotUuid}`) {
  const storageChanged = makeEvent();
  const runtimeMessages = [];
  const runtimeResponses = [];
  const activeTimers = new Set();
  function schedule(callback, delay) {
    if (Number(delay) > 2000 || Number(delay) === 250) return { suppressed: true };
    const handle = setTimeout(() => { activeTimers.delete(handle); callback(); }, 2);
    activeTimers.add(handle); return handle;
  }
  function cancel(handle) { if (handle?.suppressed) return; clearTimeout(handle); activeTimers.delete(handle); }
  const chrome = {
    runtime: {
      lastError: null,
      sendMessage(message, callback) {
        runtimeMessages.push(message);
        worker.send(message, { tab: { id: tabId, url: href } }).then((response) => { runtimeResponses.push(response); callback(response); }).catch((error) => { const response = { ok: false, code: error.code || "WORKER_ERROR", error: error.message || String(error) }; runtimeResponses.push(response); callback(response); });
      }
    },
    storage: { onChanged: storageChanged }
  };
  const context = vm.createContext({
    chrome, document: dom.document, location: { href }, URL,
    Element: DOMElement, HTMLElement: DOMElement, HTMLInputElement: DOMInput, HTMLButtonElement: DOMButton,
    Event: FakeInputEvent, InputEvent: FakeInputEvent, DataTransfer: FakeDataTransfer,
    File: globalThis.File, Blob: globalThis.Blob, TextEncoder, TextDecoder, crypto: webcrypto,
    atob: (value) => Buffer.from(value, "base64").toString("binary"),
    btoa: (value) => Buffer.from(value, "binary").toString("base64"), Buffer,
    AbortController, setTimeout: schedule, clearTimeout: cancel, queueMicrotask,
    getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }),
    console
  });
  context.__YMB_FILE_DELIVERY_CONTENT_TEST__ = true;
  for (const file of ["shared/conversation_identity.js", "shared/dot_surface.js", "shared/composer_send.js", "shared/chatgpt_file_attachment.js", "file_delivery_content.js"]) {
    vm.runInContext(fs.readFileSync(path.join(root, file), "utf8"), context, { filename: file });
  }
  return { context, storageChanged, runtimeMessages, runtimeResponses, activeTimers };
}

function createMainContentContext(worker, dom, href = `https://chatgpt.com/dots/${dotUuid}`) {
  const runtimeMessages = [];
  const chrome = {
    runtime: {
      lastError: null, onMessage: makeEvent(),
      sendMessage(message, callback) {
        runtimeMessages.push(message);
        worker.send(message, { tab: { id: tabId, url: href } }).then(callback).catch((error) => callback({ ok: false, code: error.code || "WORKER_ERROR", error: error.message || String(error) }));
      }
    }
  };
  class FakeMutationObserver { constructor(callback) { this.callback = callback; } observe() {} disconnect() {} }
  const context = vm.createContext({
    chrome, document: dom.document, location: { href }, URL,
    Element: DOMElement, HTMLElement: DOMElement, HTMLInputElement: DOMInput, HTMLButtonElement: DOMButton,
    Event: FakeInputEvent, InputEvent: FakeInputEvent, DataTransfer: FakeDataTransfer,
    File: globalThis.File, Blob: globalThis.Blob, TextEncoder, TextDecoder, crypto: webcrypto,
    AbortController, setTimeout: () => ({ suppressed: true }), clearTimeout() {}, queueMicrotask,
    getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }),
    MutationObserver: FakeMutationObserver,
    CSS: { escape: (value) => String(value).replace(/[^a-z0-9_-]/gi, "\\$&") },
    window: { innerWidth: 1200, innerHeight: 900, addEventListener() {}, removeEventListener() {} },
    console
  });
  context.__YMB_TEST__ = true;
  for (const file of [
    "shared/product.js", "shared/conversation_identity.js", "shared/dot_surface.js", "shared/service_registry.js",
    "shared/manual_controls.js", "shared/wordstat_protocol.js", "shared/search_protocol.js", "shared/metrika_protocol.js",
    "shared/direct_protocol.js", "shared/composer_send.js", "shared/proven_writing_block_capture.js", "content_script.js"
  ]) vm.runInContext(fs.readFileSync(path.join(root, file), "utf8"), context, { filename: file });
  return { context, runtimeMessages };
}

test("real YMB worker bootstrap stages complete UTF-8 Dot reports and enforces exactly-once acknowledgement", async () => {
  const worker = createWorker();
  const { context, storage } = worker;
  assert.equal(typeof context.handleMessage, "function", "full phase3/service-worker/file-delivery import chain ran");
  assert.equal(typeof context.YMBFileArtifactStore.stageTextArtifact, "function", "real IndexedDB artifact store loaded");
  assert.equal(typeof context.YMBFileDeliveryWorkerTransport.compactLargeCommandResult, "function");

  const bound = await worker.send({ type: "WS_BIND_CONVERSATION", tab_id: tabId });
  assert.equal(bound.binding.conversation_key, dotKey);
  const manual = await worker.send({ type: "WS_SET_MANUAL_MODE", conversation_key: dotKey, enabled: true, tab_id: tabId });
  assert.equal(manual.enabled, true);

  await assert.rejects(worker.send({ type: "WS_START_AUTORUN", conversation_key: dotKey, tab_id: tabId }), { code: "DOT_AUTORUN_UNSUPPORTED" });
  await assert.rejects(worker.send({ type: "WS_RESUME_AUTORUN", conversation_key: dotKey, tab_id: tabId }), { code: "DOT_AUTORUN_UNSUPPORTED" });
  const autoCommand = await worker.send({ type: "WS_AUTO_COMMAND", conversation_key: dotKey, run_id: "r1", command_text: "WORDSTAT_API_V1", assistant_turn_id: "a1" }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(autoCommand.code, "DOT_AUTORUN_UNSUPPORTED");
  assert.equal(worker.getProviderCalls(), 0);

  const first = await worker.send({ type: "WS_EXECUTE_MANUAL_BLOCK", conversation_key: dotKey, block_text: "synthetic unsupported input", manual_request_token: "manual-1" }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(first.accepted, true);
  assert.equal(first.delivery_id.length > 0, true);
  assert.equal(first.report_text.includes("NO_SUPPORTED_COMMAND"), false, "confirmed Dot file payload is compacted before runtime return");

  const wrongTab = await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId + 1, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(wrongTab.code, "AUTO_NON_OWNER_TAB");
  worker.setUrl(`https://chatgpt.com/dots/${otherUuid}`);
  const wrongPath = await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${otherUuid}` } });
  assert.equal(wrongPath.code, "CONVERSATION_MISMATCH");
  worker.setUrl(`https://chatgpt.com/dots/${dotUuid}`);

  const entry = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).outbox;
  assert.equal(entry.delivery_mode, "attachment_v2");
  assert.equal(entry.phase, "claimed");
  assert.equal(entry.artifact_descriptors.length, 1);
  assert.match(entry.report_text, /результат прикреплён файлом/);
  const descriptor = entry.artifact_descriptors[0];
  assert.ok(descriptor.byte_length > 0);
  const chunks = [];
  for (const item of descriptor.chunk_manifest) {
    const reply = await worker.send({ type: "WS_GET_OUTBOX_ARTIFACT_CHUNK", conversation_key: dotKey, delivery_id: entry.delivery_id, artifact_key: descriptor.artifact_key, chunk_index: item.chunk_index }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
    assert.equal(reply.ok, true);
    const bytes = Buffer.from(reply.chunk_base64, "base64");
    assert.equal(bytes.length, item.byte_length);
    assert.equal(createHash("sha256").update(bytes).digest("hex"), item.sha256);
    chunks.push(bytes);
  }
  const bytes = Buffer.concat(chunks);
  assert.equal(bytes.length, descriptor.byte_length);
  const fullReport = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  assert.match(fullReport, /NO_SUPPORTED_COMMAND/);

  const baseline = {
    baseline_message_ids: ["u-old-file-only", "a-anchor"],
    baseline_self_message_ids: ["u-old-file-only"],
    baseline_last_message_id: "a-anchor",
    baseline_captured: true,
    baseline_identity_key: dotKey
  };
  const committed = await worker.send({ type: "WS_MARK_ATTACHMENT_COMMITTED", conversation_key: dotKey, delivery_id: entry.delivery_id, ...baseline }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(committed.ok, true);
  assert.equal(committed.outbox.baseline_last_message_id, "a-anchor");
  const ready = await worker.send({ type: "WS_MARK_ATTACHMENT_READY", conversation_key: dotKey, delivery_id: entry.delivery_id, attached_filenames: [descriptor.filename] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(ready.ok, true);
  const caption = `Yandex Marketing Bridge: результат прикреплён файлом ${descriptor.filename}.`;
  const sendCommit = await worker.send({ type: "WS_COMMIT_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id, send_marker: caption, expected_attachment_names: [descriptor.filename] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(sendCommit.ok, true);
  assert.deepEqual(Array.from(sendCommit.outbox.baseline_message_ids), baseline.baseline_message_ids, "send commit retains the pre-attachment baseline");

  const rollback = await worker.send({ type: "WS_ROLLBACK_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id, reason: "synthetic pre-click target changed" }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(rollback.ok, true);
  assert.equal(rollback.outbox.phase, "attachment_ready");
  assert.deepEqual(Array.from(rollback.outbox.baseline_message_ids), baseline.baseline_message_ids, "pre-click rollback preserves the early Dot anchor");
  const recommit = await worker.send({ type: "WS_COMMIT_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id, send_marker: caption, expected_attachment_names: [descriptor.filename] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(recommit.ok, true, "a new validated Send attempt may reuse the same durable baseline");

  const confirmation = await worker.send({
    type: "WS_CONFIRM_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id,
    confirmation_message_id: "u-sent-1", confirmation_identity_key: dotKey,
    confirmation_ordered_message_ids: ["u-old-file-only", "a-anchor", "u-sent-1"]
  }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(confirmation.ok, true);
  assert.equal(confirmation.outbox.phase, "committed");
  const completeMessage = { type: "WS_MANUAL_DELIVERY_COMPLETE", conversation_key: dotKey, delivery_id: entry.delivery_id, confirmation_basis: "dot_attachment_match", confirmation_message_id: "u-sent-1" };
  const completionResults = await Promise.all([worker.send(completeMessage, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } }), worker.send(completeMessage, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })]);
  assert.equal(completionResults.some((result) => result.ok), true);
  assert.equal(completionResults.every((result) => result.ok), true, "duplicate complete is success only after matching confirmed operation state");
  assert.equal((await storage.wsmb_outbox)?.[dotKey], undefined);
  assert.equal(await context.YMBFileArtifactStore.getMeta(descriptor.artifact_key), undefined, "one confirmed completion clears the outbox artifact");

  const second = await worker.send({ type: "WS_EXECUTE_MANUAL_BLOCK", conversation_key: dotKey, block_text: "second synthetic unsupported input", manual_request_token: "manual-2" }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(second.accepted, true, "the next Manual admission is unlocked without an Autorun Finish step");
  assert.notEqual(second.delivery_id, first.delivery_id);
  assert.equal(worker.getProviderCalls(), 0);

  const queuedError = await worker.send({
    type: "WS_REPORT_CONTENT_ERROR", conversation_key: dotKey, service: "wordstat", channel: "content",
    stage: "SYNTHETIC_TEST", code: "SYNTHETIC_ERROR", error: "Ошибка теста 🚀".repeat(40), request_executed: false
  }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(queuedError.ok, true);
  const secondOutbox = await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(secondOutbox.outbox.type, "manual", "current Manual outbox retains priority over a queued content error");
  const secondEntry = secondOutbox.outbox;
  const secondFile = secondEntry.artifact_descriptors[0];
  const secondBaseline = {
    baseline_message_ids: ["u-old-2", "a-anchor-2"], baseline_self_message_ids: ["u-old-2"],
    baseline_last_message_id: "a-anchor-2", baseline_captured: true, baseline_identity_key: dotKey
  };
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_COMMITTED", conversation_key: dotKey, delivery_id: secondEntry.delivery_id, ...secondBaseline }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_READY", conversation_key: dotKey, delivery_id: secondEntry.delivery_id, attached_filenames: [secondFile.filename] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  const secondCaption = `Yandex Marketing Bridge: результат прикреплён файлом ${secondFile.filename}.`;
  assert.equal((await worker.send({ type: "WS_COMMIT_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: secondEntry.delivery_id, send_marker: secondCaption, expected_attachment_names: [secondFile.filename] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  assert.equal((await worker.send({ type: "WS_CONFIRM_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: secondEntry.delivery_id, confirmation_message_id: "u-sent-2", confirmation_identity_key: dotKey, confirmation_ordered_message_ids: ["u-old-2", "a-anchor-2", "u-sent-2"] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  assert.equal((await worker.send({ type: "WS_MANUAL_DELIVERY_COMPLETE", conversation_key: dotKey, delivery_id: secondEntry.delivery_id, confirmation_basis: "dot_attachment_match", confirmation_message_id: "u-sent-2" }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);

  const promoted = await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(promoted.outbox.type, "content_error");
  assert.equal(promoted.outbox.delivery_mode, "attachment_v2", "raw promoted page errors are converted to a complete Dot TXT on get-outbox");
  const errorDescriptor = promoted.outbox.artifact_descriptors[0];
  const errorChunks = [];
  for (const chunk of errorDescriptor.chunk_manifest) {
    const reply = await worker.send({ type: "WS_GET_OUTBOX_ARTIFACT_CHUNK", conversation_key: dotKey, delivery_id: promoted.outbox.delivery_id, artifact_key: errorDescriptor.artifact_key, chunk_index: chunk.chunk_index }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
    assert.equal(reply.ok, true);
    errorChunks.push(Buffer.from(reply.chunk_base64, "base64"));
  }
  assert.match(new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(errorChunks)), /Ошибка теста 🚀/);
  const errorBaseline = { baseline_message_ids: ["u-error-old", "a-error-anchor"], baseline_self_message_ids: ["u-error-old"], baseline_last_message_id: "a-error-anchor", baseline_captured: true, baseline_identity_key: dotKey };
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_COMMITTED", conversation_key: dotKey, delivery_id: promoted.outbox.delivery_id, ...errorBaseline }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_READY", conversation_key: dotKey, delivery_id: promoted.outbox.delivery_id, attached_filenames: [errorDescriptor.filename] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  const errorCaption = `Yandex Marketing Bridge: результат прикреплён файлом ${errorDescriptor.filename}.`;
  assert.equal((await worker.send({ type: "WS_COMMIT_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: promoted.outbox.delivery_id, send_marker: errorCaption, expected_attachment_names: [errorDescriptor.filename] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  const errorConfirmationId = "u-error-sent";
  assert.equal((await worker.send({ type: "WS_CONFIRM_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: promoted.outbox.delivery_id, confirmation_message_id: errorConfirmationId, confirmation_identity_key: dotKey, confirmation_ordered_message_ids: [...errorBaseline.baseline_message_ids, errorConfirmationId] }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).ok, true);
  const errorComplete = { type: "WS_MANUAL_DELIVERY_COMPLETE", conversation_key: dotKey, delivery_id: promoted.outbox.delivery_id, confirmation_basis: "dot_attachment_match", confirmation_message_id: errorConfirmationId };
  const errorCompletes = await Promise.all([worker.send(errorComplete, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } }), worker.send(errorComplete, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })]);
  assert.equal(errorCompletes.every((result) => result.ok), true, "duplicate confirmed content-error completion uses only its retained Dot receipt");
  assert.equal(worker.storage.ymb_dot_delivery_completion_receipts?.[dotKey]?.[promoted.outbox.delivery_id]?.status, "completed");
  assert.equal(worker.getProviderCalls(), 0);
});

test("real file_delivery_content attaches once, waits for the user's intercepted Send, matches the new row, and completes", async () => {
  const worker = createWorker();
  await worker.send({ type: "WS_BIND_CONVERSATION", tab_id: tabId });
  await worker.context.chrome.storage.local.set({ wsmb_auto_send: false });
  const fullReport = "synthetic manual API-shaped report 🚀\nстрока 2";
  const entry = await worker.context.putOutbox(dotKey, { delivery_id: "dot-content-e2e", operation_id: "op-dot-content-e2e", type: "manual", tab_id: tabId, report_text: fullReport, phase: "claimed" });
  await worker.context.chrome.storage.local.set({ wsmb_manual_operations: { [dotKey]: { operation_id: "op-dot-content-e2e", request_token: "manual-e2e", conversation_key: dotKey, tab_id: tabId, active_service: "wordstat", status: "delivering", delivery_id: entry.delivery_id, request_executed: false } } });
  assert.equal(entry.delivery_mode, "attachment_v2");
  const preflightOutbox = await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(preflightOutbox.outbox?.delivery_id, entry.delivery_id);
  const dom = buildContentDOM();
  const content = createContentContext(worker, dom);
  await content.context.__YMB_FILE_DELIVERY_CONTENT_TEST_API__.poll();
  const api = content.context.__YMB_FILE_DELIVERY_CONTENT_TEST_API__;
  const claimed = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).outbox;
  assert.equal(api.entryCurrent(claimed), true, JSON.stringify({ messages: content.runtimeMessages.map((message) => message.type), localPause: api.runtime.local_pause_id, deliveryPaused: claimed.delivery_paused, entryKey: claimed.conversation_key, currentKey: api.conversationKey(), signalAborted: claimed.delivery_signal?.aborted, disposed: api.runtime.disposed, sameRuntime: content.context.__YMB_FILE_DELIVERY_CONTENT_V4__ === api.runtime, ui: dom.document.documentElement.children.map((item) => ({ id: item.id, text: item.textContent, children: item.children.map((child) => child.textContent) })) }));
  api.showDeliveryControl(claimed);
  assert.ok(api.runtime.control_button?.isConnected);
  await api.processEntry(claimed);
  const attached = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).outbox;
  assert.equal(attached.phase, "attachment_ready", JSON.stringify({ messages: content.runtimeMessages.map((message) => message.type), responses: content.runtimeResponses, phase: attached.phase, runtime: { active: content.context.__YMB_FILE_DELIVERY_CONTENT_V4__?.active_entry?.phase, control: Boolean(content.context.__YMB_FILE_DELIVERY_CONTENT_V4__?.control_button), flight: content.context.__YMB_FILE_DELIVERY_CONTENT_V4__?.in_flight.size, disposed: content.context.__YMB_FILE_DELIVERY_CONTENT_V4__?.disposed } }));
  assert.equal(attached.baseline_last_message_id, "a-anchor");
  assert.deepEqual(Array.from(attached.baseline_self_message_ids), ["u-old-file-only"], "file-only self history row participates in the early baseline");
  assert.equal(dom.getAttachDispatches(), 1, "file was dispatched exactly once");
  assert.equal(dom.send.nativeClickCount || 0, 0, "auto_send=false never calls Send before the user click");
  assert.equal(dom.textbox.textContent, `Yandex Marketing Bridge: результат прикреплён файлом ${attached.artifact_descriptors[0].filename}.`);

  await api.processEntry(attached);
  assert.equal(dom.send.nativeClickCount || 0, 0, "ready/manual mode only arms the intercepted click barrier");
  const current = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).outbox;
  assert.equal(current.phase, "attachment_ready");

  let prevented = false;
  dom.send.dispatchEvent({ type: "click", target: dom.send, defaultPrevented: false, preventDefault() { this.defaultPrevented = prevented = true; }, stopPropagation() {}, stopImmediatePropagation() {} });
  assert.equal(prevented, true, "the user's Send click is intercepted before the worker barrier is committed");
  await new Promise((resolve) => setTimeout(resolve, 300));

  assert.equal(dom.send.nativeClickCount, 1, "the existing click barrier dispatched one native Send");
  assert.equal(dom.rows.at(-1).getAttribute("data-message-id"), "u-sent", "the fake native Send appended a new stable self row");
  assert.equal(await worker.context.YMBFileArtifactStore.getMeta(current.artifact_descriptors[0].artifact_key), undefined, "the confirmed outbox cleared its single artifact");
  const stored = await worker.context.chrome.storage.local.get("wsmb_outbox");
  assert.equal(stored.wsmb_outbox?.[dotKey], undefined);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_MARK_ATTACHMENT_COMMITTED").length, 1);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_COMMIT_ATTACHMENT_SEND").length, 1);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_CONFIRM_ATTACHMENT_SEND").length, 1);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_MANUAL_DELIVERY_COMPLETE").length, 1);
  assert.equal(worker.getProviderCalls(), 0);
  content.context.__YMB_FILE_DELIVERY_CONTENT_V4__?.dispose?.();
});

test("real file_delivery_content auto_send=true crosses one commit/click/ACK without a second send", async () => {
  const worker = createWorker();
  await worker.send({ type: "WS_BIND_CONVERSATION", tab_id: tabId });
  const entry = await worker.context.putOutbox(dotKey, { delivery_id: "dot-content-auto", operation_id: "op-dot-content-auto", type: "manual", tab_id: tabId, report_text: "synthetic auto-send report 🚀", phase: "claimed" });
  await worker.context.chrome.storage.local.set({ wsmb_manual_operations: { [dotKey]: { operation_id: "op-dot-content-auto", request_token: "manual-auto", conversation_key: dotKey, tab_id: tabId, active_service: "wordstat", status: "delivering", delivery_id: entry.delivery_id, request_executed: false } } });
  const dom = buildContentDOM();
  const content = createContentContext(worker, dom);
  const api = content.context.__YMB_FILE_DELIVERY_CONTENT_TEST_API__;
  await api.poll();
  let current = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).outbox;
  if (current.phase === "claimed") {
    await api.processEntry(current);
    current = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).outbox;
  }
  assert.equal(current.phase, "attachment_ready");
  await api.processEntry(current);
  assert.equal(dom.send.nativeClickCount, 1, "auto_send=true performs one actual Send after the commit barrier");
  assert.equal(dom.rows.at(-1).getAttribute("data-message-id"), "u-sent");
  const after = await worker.context.chrome.storage.local.get(["wsmb_outbox", "wsmb_manual_operations"]);
  assert.equal(after.wsmb_outbox?.[dotKey], undefined);
  assert.equal(after.wsmb_manual_operations?.[dotKey]?.status, "completed");
  assert.equal(after.wsmb_manual_operations?.[dotKey]?.delivery_confirmed, true);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_COMMIT_ATTACHMENT_SEND").length, 1);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_CONFIRM_ATTACHMENT_SEND").length, 1);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_MANUAL_DELIVERY_COMPLETE").length, 1);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_MARK_ATTACHMENT_COMMITTED").length, 1);
  assert.equal(worker.getProviderCalls(), 0);
  content.context.__YMB_FILE_DELIVERY_CONTENT_V4__?.dispose?.();
});

test("content_script pollOutbox reconciles a committed Dot attachment only; it never reattaches or clicks Send", async () => {
  const worker = createWorker();
  await worker.send({ type: "WS_BIND_CONVERSATION", tab_id: tabId });
  await worker.send({ type: "WS_SET_MANUAL_MODE", conversation_key: dotKey, enabled: true, tab_id: tabId });
  const created = await worker.context.putOutbox(dotKey, {
    delivery_id: "dot-poll-committed", operation_id: "op-poll-committed", type: "manual", tab_id: tabId,
    report_text: "committed recovery payload", phase: "claimed"
  });
  const operations = { [dotKey]: { operation_id: "op-poll-committed", request_token: "t1", conversation_key: dotKey, tab_id: tabId, active_service: "wordstat", status: "delivering", delivery_id: created.delivery_id, request_executed: false } };
  await worker.context.chrome.storage.local.set({ wsmb_manual_operations: operations });
  const owner = { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } };
  const claimed = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, owner)).outbox;
  const file = claimed.artifact_descriptors[0];
  const baseline = { baseline_message_ids: ["u-before", "a-anchor"], baseline_self_message_ids: ["u-before"], baseline_last_message_id: "a-anchor", baseline_captured: true, baseline_identity_key: dotKey };
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_COMMITTED", conversation_key: dotKey, delivery_id: claimed.delivery_id, ...baseline }, owner)).ok, true);
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_READY", conversation_key: dotKey, delivery_id: claimed.delivery_id, attached_filenames: [file.filename] }, owner)).ok, true);
  const caption = `Yandex Marketing Bridge: результат прикреплён файлом ${file.filename}.`;
  assert.equal((await worker.send({ type: "WS_COMMIT_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: claimed.delivery_id, send_marker: caption, expected_attachment_names: [file.filename] }, owner)).ok, true);
  assert.equal((await worker.send({ type: "WS_CONFIRM_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: claimed.delivery_id, confirmation_message_id: "u-confirmed", confirmation_identity_key: dotKey, confirmation_ordered_message_ids: ["u-before", "a-anchor", "u-confirmed"] }, owner)).ok, true);
  const committed = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, owner)).outbox;
  assert.equal(committed.phase, "committed");

  const dom = buildContentDOM();
  const content = createMainContentContext(worker, dom);
  await new Promise((resolve) => setTimeout(resolve, 35));
  await content.context.__YMB_CONTENT_TEST_API__.pollOutbox();
  assert.equal(dom.getAttachDispatches(), 0, "committed reload path does not attach the file again");
  assert.equal(dom.send.nativeClickCount || 0, 0, "committed reload path does not click Send again");
  assert.equal(dom.fileInput.files.length, 0);
  assert.equal(content.runtimeMessages.filter((message) => message.type === "WS_MANUAL_DELIVERY_COMPLETE").length, 1);
  assert.equal(content.runtimeMessages.some((message) => ["WS_MARK_ATTACHMENT_COMMITTED", "WS_COMMIT_ATTACHMENT_SEND", "WS_CONFIRM_ATTACHMENT_SEND", "WS_GET_OUTBOX_ARTIFACT_CHUNK"].includes(message.type)), false);
  const storage = await worker.context.chrome.storage.local.get(["wsmb_outbox", "wsmb_manual_operations"]);
  assert.equal(storage.wsmb_outbox?.[dotKey], undefined);
  assert.equal(storage.wsmb_manual_operations?.[dotKey]?.status, "completed");
  assert.equal(storage.wsmb_manual_operations?.[dotKey]?.delivery_confirmed, true);
  assert.equal(worker.getProviderCalls(), 0);
});

test("dot completion receipt recovers an interruption after outbox clear and before manual-operation update", async () => {
  const worker = createWorker();
  await worker.send({ type: "WS_BIND_CONVERSATION", tab_id: tabId });
  await worker.send({ type: "WS_SET_MANUAL_MODE", conversation_key: dotKey, enabled: true, tab_id: tabId });
  const operationResult = await worker.send({ type: "WS_EXECUTE_MANUAL_BLOCK", conversation_key: dotKey, block_text: "synthetic unsupported recovery probe", manual_request_token: "receipt-recovery-1" }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } });
  assert.equal(operationResult.accepted, true);
  const entry = (await worker.send({ type: "WS_GET_OUTBOX", conversation_key: dotKey }, { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } })).outbox;
  const descriptor = entry.artifact_descriptors[0];
  const baseline = { baseline_message_ids: ["u-early", "a-anchor"], baseline_self_message_ids: ["u-early"], baseline_last_message_id: "a-anchor", baseline_captured: true, baseline_identity_key: dotKey };
  const owner = { tab: { id: tabId, url: `https://chatgpt.com/dots/${dotUuid}` } };
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_COMMITTED", conversation_key: dotKey, delivery_id: entry.delivery_id, ...baseline }, owner)).ok, true);
  assert.equal((await worker.send({ type: "WS_MARK_ATTACHMENT_READY", conversation_key: dotKey, delivery_id: entry.delivery_id, attached_filenames: [descriptor.filename] }, owner)).ok, true);
  const caption = `Yandex Marketing Bridge: результат прикреплён файлом ${descriptor.filename}.`;
  assert.equal((await worker.send({ type: "WS_COMMIT_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id, send_marker: caption, expected_attachment_names: [descriptor.filename] }, owner)).ok, true);
  assert.equal((await worker.send({ type: "WS_CONFIRM_ATTACHMENT_SEND", conversation_key: dotKey, delivery_id: entry.delivery_id, confirmation_message_id: "u-receipt-confirmed", confirmation_identity_key: dotKey, confirmation_ordered_message_ids: ["u-early", "a-anchor", "u-receipt-confirmed"] }, owner)).ok, true);

  worker.failNextStorageSet("wsmb_manual_operations");
  const completion = { type: "WS_MANUAL_DELIVERY_COMPLETE", conversation_key: dotKey, delivery_id: entry.delivery_id, confirmation_basis: "dot_attachment_match", confirmation_message_id: "u-receipt-confirmed" };
  await assert.rejects(worker.send(completion, owner), { code: "INJECTED_STORAGE_FAILURE" });
  assert.equal(worker.storage.wsmb_outbox?.[dotKey], undefined, "the injected interruption is after durable outbox removal");
  assert.equal(worker.storage.wsmb_manual_operations?.[dotKey]?.status, "delivering", "operation update did not happen before the simulated crash");
  const receipt = worker.storage.ymb_dot_delivery_completion_receipts?.[dotKey]?.[entry.delivery_id];
  assert.equal(receipt?.confirmation_message_id, "u-receipt-confirmed", "exact confirmed-send evidence was durable before removal");
  assert.equal(receipt?.operation_id, operationResult.operation_id);

  const restarted = createWorker({ storage: worker.storage, indexedDB: worker.indexedDB });
  const state = await restarted.send({ type: "WS_GET_STATE", conversation_key: dotKey }, owner);
  assert.equal(state.state.manual_operation.status, "completed");
  assert.equal(restarted.storage.wsmb_manual_operations?.[dotKey]?.delivery_confirmed, true);
  assert.equal(restarted.storage.wsmb_manual_operations?.[dotKey]?.delivery_id, entry.delivery_id);
  assert.equal(restarted.storage.ymb_dot_delivery_completion_receipts?.[dotKey]?.[entry.delivery_id]?.status, "completed", "reconciled receipt becomes a bounded idempotency tombstone only after durable operation completion");
  assert.deepEqual(restarted.storage.ymb_dot_delivery_completion_receipts?.[dotKey]?.[entry.delivery_id]?.artifact_descriptors, []);
  assert.equal(restarted.storage.wsmb_outbox?.[dotKey], undefined, "reconciliation did not create or clear any unrelated outbox");
  assert.equal(await restarted.context.YMBFileArtifactStore.getMeta(descriptor.artifact_key), undefined, "old delivery artifact remains cleaned after restart");

  const next = await restarted.send({ type: "WS_EXECUTE_MANUAL_BLOCK", conversation_key: dotKey, block_text: "next synthetic unsupported probe", manual_request_token: "receipt-recovery-2" }, owner);
  assert.equal(next.accepted, true, "next Manual admission unlocks after receipt reconciliation");
  assert.notEqual(next.delivery_id, entry.delivery_id);
  assert.equal(worker.getProviderCalls() + restarted.getProviderCalls(), 0);
});

test("Dot receipt write failure leaves committed outbox and artifact untouched", async () => {
  const worker = createWorker();
  const prepared = await prepareCommittedManualAttachment(worker, "receipt-write-fail");
  worker.failNextStorageSet("ymb_dot_delivery_completion_receipts");
  await assert.rejects(worker.send(prepared.completion, prepared.owner), { code: "INJECTED_STORAGE_FAILURE" });
  assert.equal(worker.storage.wsmb_outbox?.[dotKey]?.delivery_id, prepared.entry.delivery_id);
  assert.equal(worker.storage.wsmb_outbox?.[dotKey]?.phase, "committed");
  assert.equal(worker.storage.wsmb_manual_operations?.[dotKey]?.status, "delivering");
  assert.ok(await worker.context.YMBFileArtifactStore.getMeta(prepared.descriptor.artifact_key), "no artifact cleanup ran before durable receipt write");
  assert.equal(worker.storage.ymb_dot_delivery_completion_receipts?.[dotKey], undefined);
});

test("Dot completion fails closed before receipt or cleanup when the current manual-operation owner tuple mismatches", async () => {
  const worker = createWorker();
  const prepared = await prepareCommittedManualAttachment(worker, "operation-fence");
  const originalMap = worker.storage.wsmb_manual_operations;
  const originalOperation = originalMap[dotKey];
  const mismatches = [
    { operation_id: "stale-operation" },
    { delivery_id: "stale-delivery" },
    { tab_id: tabId + 1 },
    { status: "queued" }
  ];
  for (const mismatch of mismatches) {
    worker.storage.wsmb_manual_operations = {
      ...originalMap,
      [dotKey]: { ...originalOperation, ...mismatch }
    };
    const result = await worker.send(prepared.completion, prepared.owner);
    assert.equal(result.ok, false);
    assert.equal(result.code, "DOT_COMPLETION_OPERATION_MISMATCH");
    assert.equal(worker.storage.wsmb_outbox?.[dotKey]?.delivery_id, prepared.entry.delivery_id, "mismatch cannot clear the confirmed outbox");
    assert.equal(worker.storage.wsmb_outbox?.[dotKey]?.phase, "committed");
    assert.ok(await worker.context.YMBFileArtifactStore.getMeta(prepared.descriptor.artifact_key), "mismatch cannot clean the artifact");
    assert.equal(worker.storage.ymb_dot_delivery_completion_receipts?.[dotKey]?.[prepared.entry.delivery_id], undefined, "mismatch cannot create a durable receipt");
  }
  worker.storage.wsmb_manual_operations = originalMap;
  assert.equal((await worker.send(prepared.completion, prepared.owner)).ok, true, "the exact current operation/owner tuple still completes normally");
  assert.equal(worker.storage.wsmb_outbox?.[dotKey], undefined);
  assert.equal(worker.getProviderCalls(), 0);
});

test("Dot receipt survives a failed receipt-clear write after completion and reconciles on restart", async () => {
  const worker = createWorker();
  const prepared = await prepareCommittedManualAttachment(worker, "receipt-clear-fail");
  worker.failStorageSetAfter("ymb_dot_delivery_completion_receipts", 1);
  await assert.rejects(worker.send(prepared.completion, prepared.owner), { code: "INJECTED_STORAGE_FAILURE" });
  assert.equal(worker.storage.wsmb_outbox?.[dotKey], undefined, "completion crossed the durable outbox-clear boundary");
  assert.equal(worker.storage.wsmb_manual_operations?.[dotKey]?.status, "completed");
  assert.ok(worker.storage.ymb_dot_delivery_completion_receipts?.[dotKey]?.[prepared.entry.delivery_id]);

  const restarted = createWorker({ storage: worker.storage, indexedDB: worker.indexedDB });
  const state = await restarted.send({ type: "WS_GET_STATE", conversation_key: dotKey }, prepared.owner);
  assert.equal(state.state.manual_operation.status, "completed");
  assert.equal(restarted.storage.ymb_dot_delivery_completion_receipts?.[dotKey]?.[prepared.entry.delivery_id]?.status, "completed", "receipt becomes a bounded idempotency tombstone after recovery");
  assert.equal(restarted.storage.wsmb_outbox?.[dotKey], undefined);
  const next = await restarted.send({ type: "WS_EXECUTE_MANUAL_BLOCK", conversation_key: dotKey, block_text: "next after receipt clear recovery", manual_request_token: "after-receipt-clear" }, prepared.owner);
  assert.equal(next.accepted, true);
  assert.equal(worker.getProviderCalls() + restarted.getProviderCalls(), 0);
});

test("/c/ plain-text delivery threshold stays at the original 1,048,000 Unicode characters", async () => {
  const worker = createWorker();
  const conversationKey = `https://chatgpt.com|${dotUuid}`;
  const exact = await worker.context.putOutbox(conversationKey, { delivery_id: "c-exact", type: "manual", tab_id: tabId, report_text: "x".repeat(1_048_000), phase: "claimed" });
  assert.equal(exact.delivery_mode, undefined, "exact threshold remains plain text on /c/");
  await worker.context.clearOutbox(conversationKey, "c-exact");
  const over = await worker.context.putOutbox(conversationKey, { delivery_id: "c-over", type: "manual", tab_id: tabId, report_text: "x".repeat(1_048_001), phase: "claimed" });
  assert.equal(over.delivery_mode, "attachment_v2", "only the original over-threshold case becomes a file on /c/");
  assert.equal(over.artifact_descriptors[0].byte_length, 1_048_001);
  await worker.context.clearOutbox(conversationKey, "c-over");
  assert.equal(worker.getProviderCalls(), 0);
});
