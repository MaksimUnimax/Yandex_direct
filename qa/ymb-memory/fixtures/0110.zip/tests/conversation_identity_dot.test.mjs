import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const uuid = "6a82924e-5ed0-83eb-84a2-851ddad40c88";

function loadIdentity() {
  const context = vm.createContext({ URL });
  vm.runInContext(fs.readFileSync(path.join(root, "shared/conversation_identity.js"), "utf8"), context, { filename: "shared/conversation_identity.js" });
  return context.BB2ConversationIdentity;
}

test("Dot uses a separate identity namespace; /c/ behavior stays unchanged", () => {
  const identity = loadIdentity();
  const dotUrl = `https://chatgpt.com/dots/${uuid}`;
  const dot = identity.identityFromUrl(dotUrl);
  assert.equal(dot.status, "confirmed");
  assert.equal(dot.origin, "https://chatgpt.com");
  assert.equal(dot.conversation_id, `dots:${uuid}`);
  assert.equal(dot.conversation_key, `https://chatgpt.com|dots:${uuid}`);
  assert.equal(dot.chat_path, `/dots/${uuid}`);
  assert.equal(identity.normalizeConversationKey(dot.conversation_key, { required: true }), dot.conversation_key);

  const ordinary = identity.identityFromCandidates([`https://chatgpt.com/c/${uuid}`, `https://chatgpt.com/c/${uuid}`]);
  assert.equal(ordinary.status, "confirmed");
  assert.equal(ordinary.conversation_id, uuid);
  assert.equal(ordinary.conversation_key, `https://chatgpt.com|${uuid}`);
  assert.notEqual(ordinary.conversation_key, dot.conversation_key);
  assert.equal(identity.sameConversation(ordinary.conversation_key, dot.conversation_key), false);
});

test("Dot identity fails closed for invalid routes and conflicting or empty canonical candidates", () => {
  const identity = loadIdentity();
  const valid = `https://chatgpt.com/dots/${uuid}`;
  const invalid = identity.identityFromCandidates(["https://chatgpt.com/dots/not-a-uuid", `https://chatgpt.com/c/${uuid}`]);
  assert.notEqual(invalid.status, "confirmed");
  assert.equal(invalid.conversation_key, "");

  const staleCanonical = identity.identityFromCandidates([valid, `https://chatgpt.com/c/${uuid}`]);
  assert.equal(staleCanonical.status, "conflict");
  assert.equal(staleCanonical.conversation_key, "");

  const emptyCanonical = identity.identityFromCandidates([valid, "https://chatgpt.com/"]);
  assert.equal(emptyCanonical.status, "conflict");
  assert.equal(emptyCanonical.conversation_key, "");

  const malformedCanonical = identity.identityFromCandidates([valid, "https://chatgpt.com/dots/not-a-uuid"]);
  assert.equal(malformedCanonical.status, "conflict");
  assert.equal(malformedCanonical.conversation_key, "");
});

test("Dot keys are accepted only for exact chatgpt.com origin", () => {
  const identity = loadIdentity();
  const wrongOrigin = identity.identityFromUrl(`https://chat.openai.com/dots/${uuid}`);
  assert.notEqual(wrongOrigin.status, "confirmed");
  assert.equal(wrongOrigin.conversation_key, "");
  assert.equal(identity.normalizeConversationKey(`https://chat.openai.com|dots:${uuid}`), "");
  assert.throws(() => identity.normalizeConversationKey(`https://chat.openai.com|dots:${uuid}`, { required: true }), { code: "CONVERSATION_KEY_INVALID" });
});
