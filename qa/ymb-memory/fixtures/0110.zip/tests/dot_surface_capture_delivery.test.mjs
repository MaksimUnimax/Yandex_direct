import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const uuid = "6a82924e-5ed0-83eb-84a2-851ddad40c88";
const dotHref = `https://chatgpt.com/dots/${uuid}`;

class FixtureElement {
  constructor(tag, attrs = {}, text = "") {
    this.tagName = String(tag).toUpperCase();
    this.attrs = { ...attrs };
    this.textContent = String(text);
    this.innerText = String(text);
    this.children = [];
    this.parentElement = null;
    this.isConnected = true;
    this.rect = { x: 0, y: 0, left: 0, top: 0, right: 30, bottom: 20, width: 30, height: 20 };
    this.selectors = new Map();
    this.classList = {
      contains: (name) => String(this.attrs.class || "").split(/\s+/).includes(name),
      [Symbol.iterator]: function* () { yield* String(this.owner.attrs.class || "").split(/\s+/).filter(Boolean); },
      owner: this
    };
  }
  append(...children) { for (const child of children) { this.children.push(child); child.parentElement = this; } }
  setSelector(selector, values) { this.selectors.set(selector, [...values]); }
  getAttribute(name) { return Object.hasOwn(this.attrs, name) ? String(this.attrs[name]) : null; }
  hasAttribute(name) { return Object.hasOwn(this.attrs, name); }
  querySelectorAll(selector) { return [...(this.selectors.get(selector) || [])]; }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
  matches(selector) {
    if (selector === "article.message-row") return this.tagName === "ARTICLE" && this.classList.contains("message-row");
    if (selector === "article.message-row.self[data-message-id]") return this.tagName === "ARTICLE" && this.classList.contains("message-row") && this.classList.contains("self") && Boolean(this.getAttribute("data-message-id"));
    if (selector === '[data-orbit-message-block="codeBlock"]') return this.getAttribute("data-orbit-message-block") === "codeBlock";
    if (selector === '[aria-busy="true"]') return this.getAttribute("aria-busy") === "true";
    return false;
  }
  closest(selector) {
    for (let node = this; node; node = node.parentElement) {
      if (selector === '[data-orbit-message-parts="true"]' && node.getAttribute("data-orbit-message-parts") === "true") return node;
      if (selector === '[data-orbit-message-block="codeBlock"]' && node.matches(selector)) return node;
      if (selector === "article.message-row[data-message-id]" && node.tagName === "ARTICLE" && node.classList.contains("message-row") && node.getAttribute("data-message-id")) return node;
    }
    return null;
  }
  contains(other) { return this === other || this.children.some((child) => child.contains(other)); }
  getBoundingClientRect() { return this.rect; }
}

function makeDoc(selectorMap = {}) {
  return { querySelectorAll(selector) { return [...(selectorMap[selector] || [])]; }, querySelector(selector) { return this.querySelectorAll(selector)[0] || null; } };
}

function makeCodeBlock({ role = "assistant", id = "a1", text = "const answer = 42;\n", visible = true } = {}) {
  const row = new FixtureElement("article", { class: role === "user" ? "message-row self" : "message-row", "data-message-id": id });
  const part = new FixtureElement("div", { "data-orbit-message-parts": "true" });
  const style = new FixtureElement("div", { "data-markdown-text-style": "assistant-message" }, role);
  const block = new FixtureElement("div", { "data-orbit-message-block": "codeBlock" });
  const surface = new FixtureElement("div", { "data-markdown-copy": "code-block" });
  const code = new FixtureElement("code", {}, text);
  const copy = new FixtureElement("button", { "aria-label": "Копировать" }, "Копировать");
  const unrelatedPre = new FixtureElement("pre", {}, "not the code payload");
  if (!visible) block.rect = { ...block.rect, width: 0, height: 0, right: 0, bottom: 0 };
  row.append(part); part.append(style, block); block.append(surface, unrelatedPre); surface.append(code, copy);
  part.setSelector('[data-markdown-text-style="assistant-message"]', [style]);
  part.setSelector('[data-orbit-message-block="codeBlock"]', [block]);
  block.setSelector('[data-markdown-copy="code-block"]', [surface]);
  surface.setSelector("code", [code]);
  surface.setSelector('button[aria-label="Копировать"]', [copy]);
  return { row, part, block, surface, code, copy, unrelatedPre };
}

function makeContext(doc, extra = {}) {
  const context = vm.createContext({
    URL,
    location: { href: dotHref },
    document: doc,
    getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }),
    ...extra
  });
  for (const name of ["shared/dot_surface.js", "shared/proven_writing_block_capture.js"]) {
    vm.runInContext(fs.readFileSync(path.join(root, name), "utf8"), context, { filename: name });
  }
  return context;
}

function resourceCard(filename, { state = null, dataError = undefined, unknownNested = false } = {}) {
  const card = new FixtureElement("div", { class: "group/resource-card", ...(state ? { "data-state": state } : {}), ...(dataError === undefined ? {} : { "data-error": dataError }) });
  const open = new FixtureElement("button", { type: "button", "aria-label": `Открыть ${filename}`, "aria-busy": "false" });
  const wrapper = new FixtureElement("div", { class: "pointer-events-none relative flex" });
  const icon = new FixtureElement("svg");
  const pathNode = new FixtureElement("path");
  const label = new FixtureElement("span", { title: filename, class: "truncate" }, filename);
  wrapper.append(icon, label); icon.append(pathNode);
  card.append(open, wrapper);
  card.setSelector('button[aria-label^="Открыть "][type="button"]', [open]);
  card.setSelector("span[title]", [label]);
  card.setSelector('[aria-busy], [data-state], [data-status], [data-upload-status], [data-error], [role="alert"]', []);
  wrapper.setSelector("*", unknownNested ? [icon, label, new FixtureElement("div")] : [icon, pathNode, label]);
  return { card, open, wrapper, icon, pathNode, label };
}

function selfMessage(id, text, files = [], extra = {}) {
  const row = new FixtureElement("article", { class: "message-row self", "data-message-id": id, ...(extra.rowAttrs || {}) });
  if (text !== null) {
    const unit = new FixtureElement("div", { "data-content-search-unit-key": `${id}:message`, class: "message-text" }, text);
    row.setSelector(".message-text[data-content-search-unit-key]", [unit]);
    row.append(unit);
  } else row.setSelector(".message-text[data-content-search-unit-key]", []);
  if (files !== null) {
    const list = new FixtureElement("div", { class: "attachment-list" });
    const surface = new FixtureElement("div", { class: "message-surface" });
    const resourceCards = files.map((file) => file.card || resourceCard(file.name || file).card);
    surface.append(...resourceCards); list.append(surface);
    list.setSelector('[class*="group/resource-card"]', resourceCards);
    if (extra.unknownListSibling) list.append(new FixtureElement("div", { class: "unknown-upload-state" }));
    row.setSelector(".attachment-list", [list]);
    row.append(list);
  } else row.setSelector(".attachment-list", []);
  return row;
}

test("Dot capture binds only visible assistant codeBlock and reads exactly its code surface", () => {
  const assistant = makeCodeBlock({ role: "assistant", id: "a-assistant", text: "ONLY_CODE_PAYLOAD\n" });
  const user = makeCodeBlock({ role: "user", id: "u-user", text: "USER_PAYLOAD" });
  const hidden = makeCodeBlock({ role: "assistant", id: "a-hidden", text: "HIDDEN", visible: false });
  const doc = makeDoc({ '[data-orbit-message-parts="true"]': [assistant.part, user.part, hidden.part] });
  const context = makeContext(doc);
  const capture = context.BB2ProvenWritingCapture;
  assert.deepEqual(Array.from(capture.candidateBlocks(doc)), [assistant.block]);
  assert.equal(capture.textFromBlock(assistant.block), "ONLY_CODE_PAYLOAD\n");
  assert.equal(capture.blockForCopy(assistant.copy), assistant.block);
  assert.equal(capture.blockForCopy(user.copy), null, "self/user row is not accepted even when it has assistant-message style");
  assert.equal(capture.textFromBlock(user.block), "");
  assistant.block.isConnected = false;
  assert.equal(capture.textFromBlock(assistant.block), "");
});

test("Dot file ACK needs one new self row after the full anchor with exact caption and file multiset", () => {
  const fileOnly = selfMessage("u-file-only", null, [{ name: "old.pdf" }]);
  const oldDuplicate = selfMessage("u-old-duplicate", "Exact caption", [{ name: "report.txt" }]);
  const anchor = new FixtureElement("article", { class: "message-row", "data-message-id": "a-anchor" });
  const sent = selfMessage("u-new", "  Exact\u00a0caption\r\n", [{ name: "report.txt" }]);
  const rows = [fileOnly, oldDuplicate, anchor, sent];
  const doc = makeDoc({
    "article.message-row": rows,
    "article.message-row.self[data-message-id]": [fileOnly, oldDuplicate, sent]
  });
  const context = makeContext(doc);
  const entry = {
    conversation_key: `https://chatgpt.com|dots:${uuid}`,
    baseline_captured: true,
    baseline_identity_key: `https://chatgpt.com|dots:${uuid}`,
    baseline_message_ids: ["u-file-only", "u-old-duplicate", "a-anchor"],
    baseline_self_message_ids: ["u-file-only", "u-old-duplicate"],
    baseline_last_message_id: "a-anchor",
    send_marker: "Exact caption",
    expected_attachment_names: ["report.txt"]
  };
  const match = context.YMBDotSurface.findNewMatchingUserMessage(entry, doc);
  assert.equal(match?.id, "u-new");
  assert.deepEqual(Array.from(match.ordered_message_ids), ["u-file-only", "u-old-duplicate", "a-anchor", "u-new"]);

  const quote = new FixtureElement("article", { class: "message-row", "data-message-id": "a-quote" });
  quote.setSelector(".message-text[data-content-search-unit-key]", [new FixtureElement("div", { "data-content-search-unit-key": "a-quote:text" }, "Exact caption")]);
  const quoteDoc = makeDoc({ "article.message-row": [fileOnly, oldDuplicate, anchor, quote], "article.message-row.self[data-message-id]": [fileOnly, oldDuplicate] });
  assert.equal(context.YMBDotSurface.findNewMatchingUserMessage(entry, quoteDoc), null, "assistant quote is not a user confirmation");

  const badFile = selfMessage("u-new", "Exact caption", [{ name: "other.txt" }]);
  const badFileDoc = makeDoc({ "article.message-row": [fileOnly, oldDuplicate, anchor, badFile], "article.message-row.self[data-message-id]": [fileOnly, oldDuplicate, badFile] });
  assert.equal(context.YMBDotSurface.findNewMatchingUserMessage(entry, badFileDoc), null, "caption-only / wrong file set cannot confirm");

  const duplicateNew = selfMessage("u-new-2", "Exact caption", [{ name: "report.txt" }]);
  const ambiguousDoc = makeDoc({ "article.message-row": [...rows, duplicateNew], "article.message-row.self[data-message-id]": [fileOnly, oldDuplicate, sent, duplicateNew] });
  assert.equal(context.YMBDotSurface.findNewMatchingUserMessage(entry, ambiguousDoc), null, "two matching new messages are ambiguous");
});

test("Unknown attachment children, upload state, and empty data-error fail closed", () => {
  const context = makeContext(makeDoc());
  const anchor = new FixtureElement("article", { class: "message-row", "data-message-id": "a-anchor" });
  const fileOnly = selfMessage("u-file-only", null, [{ name: "old.pdf" }]);
  const expected = { baseline_message_ids: ["u-file-only", "a-anchor"], baseline_self_message_ids: ["u-file-only"], baseline_last_message_id: "a-anchor", send_marker: "caption", expected_attachment_names: ["report.txt"] };
  const knownPlusUnknown = selfMessage("u-new", "caption", [{ name: "report.txt" }], { unknownListSibling: true });
  const unknownDoc = makeDoc({ "article.message-row": [fileOnly, anchor, knownPlusUnknown], "article.message-row.self[data-message-id]": [fileOnly, knownPlusUnknown] });
  assert.equal(context.YMBDotSurface.findNewMatchingUserMessage(expected, unknownDoc), null, "one known report card plus unknown list child is not an exact attachment multiset");

  const uploading = selfMessage("u-new", "caption", [resourceCard("report.txt", { state: "uploading" })]);
  const uploadingDoc = makeDoc({ "article.message-row": [fileOnly, anchor, uploading], "article.message-row.self[data-message-id]": [fileOnly, uploading] });
  assert.equal(context.YMBDotSurface.findNewMatchingUserMessage(expected, uploadingDoc), null, "an explicit uploading state is not a sent/ready resource card");

  const errored = selfMessage("u-new", "caption", [resourceCard("report.txt", { dataError: "" })]);
  const errorDoc = makeDoc({ "article.message-row": [fileOnly, anchor, errored], "article.message-row.self[data-message-id]": [fileOnly, errored] });
  assert.equal(context.YMBDotSurface.findNewMatchingUserMessage(expected, errorDoc), null, "present empty data-error is not evidence of success");
});

function composerFixture({ unknownSibling = false, card = null, inputFiles = [] } = {}) {
  const textbox = new FixtureElement("div", { "data-composer-markdown": "", contenteditable: "true", role: "textbox", "aria-label": "Сообщение" });
  const send = new FixtureElement("button", { "aria-label": "Отправить" });
  const footer = new FixtureElement("div", { "data-composer-footer-responsive": "" });
  footer.append(textbox, send);
  footer.setSelector('div[data-composer-markdown][contenteditable="true"][role="textbox"][aria-label="Сообщение"]', [textbox]);
  footer.setSelector('button[aria-label="Отправить"]', [send]);
  const input = new FixtureElement("input", { type: "file", "data-role": "file-input", multiple: "" });
  input.files = inputFiles;
  const row = new FixtureElement("div", { "data-composer-attachments-row": "true" });
  if (card) row.append(card);
  const attachments = new FixtureElement("div", { "data-composer-attachments": "true" });
  attachments.append(row);
  if (unknownSibling) attachments.append(new FixtureElement("div", { "data-state": "uploading" }));
  attachments.setSelector('[data-composer-attachments-row="true"]', [row]);
  attachments.textContent = card ? "file" : "";
  const rootNode = new FixtureElement("div", { "data-role": "composer" });
  rootNode.append(footer, attachments, input);
  rootNode.setSelector('input[type="file"][data-role="file-input"][multiple]', [input]);
  rootNode.setSelector("[data-composer-attachments]", [attachments]);
  const doc = makeDoc({ "[data-composer-footer-responsive]": [footer], '[data-role="composer"]': [rootNode] });
  return { doc, footer, textbox, send, input, row, attachments, rootNode };
}

test("Composer and file input are scoped to one known Dot composer; unknown sibling blocks readiness", () => {
  const fixture = composerFixture({ unknownSibling: true });
  const context = makeContext(fixture.doc);
  assert.equal(context.YMBDotSurface.dotComposerContext(fixture.doc)?.composer, fixture.textbox);
  assert.equal(context.YMBDotSurface.dotSendButton(context.YMBDotSurface.dotComposerContext(fixture.doc)), fixture.send);
  assert.equal(context.YMBDotSurface.dotComposerShell(fixture.doc), null, "known row plus unknown upload-state sibling is ambiguous");
  assert.equal(context.YMBDotSurface.attachmentSnapshot(fixture.doc), null);

  const duplicate = composerFixture();
  duplicate.doc.querySelectorAll = (selector) => selector === "[data-composer-footer-responsive]" ? [duplicate.footer, new FixtureElement("div", { "data-composer-footer-responsive": "" })] : selector === '[data-role="composer"]' ? [duplicate.rootNode] : [];
  assert.equal(context.YMBDotSurface.dotComposerContext(duplicate.doc), null, "multiple visible Dot footers fail closed");
});
