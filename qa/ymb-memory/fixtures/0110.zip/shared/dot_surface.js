(() => {
  "use strict";

  // Small, isolated adapter for the observed ChatGPT Dot DOM. This module is
  // intentionally a DOM/identity surface only; it contains no provider,
  // batching, or job orchestration logic.
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const DOT_PATH = /^\/dots\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\/?$/i;
  const COPY_ANCHORS = new WeakMap();

  function locationParts(value = globalThis.location) {
    try {
      const url = value instanceof URL ? value : new URL(String(value?.href || value || ""));
      return { origin: url.origin.toLowerCase(), pathname: url.pathname };
    } catch { return { origin: "", pathname: "" }; }
  }

  function dotIdFromPath(pathname) {
    const match = String(pathname || "").match(DOT_PATH);
    return match ? match[1].toLowerCase() : "";
  }

  function isDotLocation(value = globalThis.location) {
    const parts = locationParts(value);
    return parts.origin === "https://chatgpt.com" && Boolean(dotIdFromPath(parts.pathname));
  }

  function hasDotNamespace(value = globalThis.location) {
    const parts = locationParts(value);
    return parts.origin === "https://chatgpt.com" && /^\/dots(?:\/|$)/i.test(parts.pathname);
  }

  function visible(node) {
    if (!node?.isConnected || typeof node.getBoundingClientRect !== "function") return false;
    try {
      const style = globalThis.getComputedStyle?.(node);
      if (style && (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0)) return false;
      const rect = node.getBoundingClientRect();
      return Number(rect.width) > 0 && Number(rect.height) > 0;
    } catch { return false; }
  }

  function assistantMessages(doc = globalThis.document) {
    if (!isDotLocation() || !doc?.querySelectorAll) return [];
    return [...doc.querySelectorAll('[data-orbit-message-parts="true"]')]
      .filter((node) => node.querySelector('[data-markdown-text-style="assistant-message"]'))
      .filter((node) => {
        const row = node.closest?.("article.message-row[data-message-id]");
        return Boolean(row && !row.classList?.contains?.("self") && row.contains(node));
      })
      .filter((node) => !node.parentElement?.closest?.('[data-orbit-message-parts="true"]'));
  }

  function findCodeBlocks(doc = globalThis.document) {
    const blocks = [];
    for (const message of assistantMessages(doc)) {
      for (const block of message.querySelectorAll('[data-orbit-message-block="codeBlock"]')) {
        const row = block.closest?.("article.message-row[data-message-id]");
        if (!row || row.classList?.contains?.("self") || !row.contains(message)) continue;
        if (!block.isConnected || !visible(block)) continue;
        const surfaces = block.querySelectorAll('[data-markdown-copy="code-block"]');
        if (surfaces.length !== 1) continue;
        const surface = surfaces[0];
        const codes = surface.querySelectorAll("code");
        const copies = surface.querySelectorAll('button[aria-label="Копировать"]');
        if (codes.length !== 1 || copies.length !== 1 || !copies[0].isConnected || !visible(copies[0])) continue;
        COPY_ANCHORS.set(block, copies[0]);
        blocks.push(block);
      }
    }
    return blocks;
  }

  function codeSurface(block) {
    if (!block?.isConnected) return null;
    const surfaces = block.querySelectorAll?.('[data-markdown-copy="code-block"]') || [];
    return surfaces.length === 1 ? surfaces[0] : null;
  }

  function textFromBlock(block) {
    const surface = codeSurface(block);
    const codes = surface?.querySelectorAll?.("code") || [];
    return codes.length === 1 ? String(codes[0].textContent || "").replace(/\r\n?/g, "\n") : "";
  }

  function geometryAnchor(block) {
    const copy = block && COPY_ANCHORS.get(block);
    return copy?.isConnected && visible(copy) ? copy : null;
  }

  function assistantRowId(block) {
    const row = block?.closest?.("article.message-row[data-message-id]");
    return row && !row.matches(".self") ? String(row.getAttribute("data-message-id") || "") : "";
  }

  function dotComposerContext(doc = globalThis.document) {
    if (!isDotLocation() || !doc?.querySelectorAll) return null;
    const footers = [...doc.querySelectorAll("[data-composer-footer-responsive]")].filter(visible);
    if (footers.length !== 1) return null;
    const root = footers[0];
    const composers = [...root.querySelectorAll('div[data-composer-markdown][contenteditable="true"][role="textbox"][aria-label="Сообщение"]')].filter(visible);
    if (composers.length !== 1) return null;
    return { doc, composer: composers[0], root, form: null };
  }

  function dotSendButton(context) {
    const root = context?.root;
    if (!root?.isConnected || !root.contains?.(context?.composer)) return null;
    const buttons = [...root.querySelectorAll('button[aria-label="Отправить"]')].filter(visible);
    return buttons.length === 1 ? buttons[0] : null;
  }

  function dotComposerShell(doc = globalThis.document) {
    const context = dotComposerContext(doc);
    if (!context) return null;
    const roots = [...doc.querySelectorAll('[data-role="composer"]')]
      .filter((node) => node.isConnected && node.contains(context.composer) && node.contains(context.root));
    if (roots.length !== 1) return null;
    const root = roots[0];
    const inputs = [...root.querySelectorAll('input[type="file"][data-role="file-input"][multiple]')].filter((node) => node.isConnected);
    if (inputs.length !== 1) return null;
    const attachmentRoots = [...root.querySelectorAll("[data-composer-attachments]")];
    if (attachmentRoots.length > 1) return null;
    const attachmentRoot = attachmentRoots[0] || null;
    if (!attachmentRoot) {
      const loose = root.querySelectorAll('[class*="attachment"], [class*="upload"], [data-file-name], [data-filename], [data-composer-attachments-row], [role="alert"]');
      if ((inputs[0].files?.length || 0) || loose.length) return null;
      return { context, root, input: inputs[0], attachmentRoot: null, row: null };
    }
    const rows = [...attachmentRoot.querySelectorAll('[data-composer-attachments-row="true"]')];
    if (rows.length > 1) return null;
    if (rows.length === 1 && (attachmentRoot.children?.length !== 1 || attachmentRoot.children[0] !== rows[0])) return null;
    if (!rows.length && (attachmentRoot.children?.length || String(attachmentRoot.textContent || "").trim())) return null;
    return { context, root, input: inputs[0], attachmentRoot, row: rows[0] || null };
  }

  function composerAttachmentCards(doc = globalThis.document) {
    const shell = dotComposerShell(doc);
    if (!shell) return null;
    const cards = [];
    for (const card of [...(shell.row?.children || [])]) {
      if (!card.classList?.contains?.("group/composer-attachment")) return null;
      const names = [...card.querySelectorAll("span.truncate")];
      if (names.length !== 1) return null;
      const filename = String(names[0].textContent || "").replace(/\s+/g, " ").trim();
      if (!filename) return null;
      const removeButtons = [...card.querySelectorAll("button[aria-label]")]
        .filter((button) => String(button.getAttribute("aria-label") || "") === `Удалить ${filename}`);
      if (removeButtons.length !== 1) return null;
      const stateNodes = [card, ...card.querySelectorAll('[aria-busy], [data-state], [data-status], [data-upload-status], [data-error], [role="alert"]')];
      let busy = false;
      let error = false;
      for (const node of stateNodes) {
        const ariaBusy = String(node.getAttribute?.("aria-busy") || "").toLowerCase();
        const state = [node.getAttribute?.("data-state"), node.getAttribute?.("data-status"), node.getAttribute?.("data-upload-status")]
          .map((value) => String(value || "").toLowerCase()).join(" ");
        const errorValue = node.getAttribute?.("data-error");
        busy ||= ariaBusy === "true" || /upload|loading|загружа|обработ/.test(state);
        error ||= (errorValue !== null && String(errorValue).toLowerCase() !== "false") || /error|failed|ошиб|сбой/.test(`${state} ${node.getAttribute?.("aria-label") || ""}`.toLowerCase()) || node.getAttribute?.("role") === "alert";
      }
      cards.push({ node: card, filename, busy, error });
    }
    return { shell, cards };
  }

  function attachmentSnapshot(doc = globalThis.document) {
    const result = composerAttachmentCards(doc);
    if (!result) return null;
    const inputFiles = [...(result.shell.input.files || [])].map((file) => ({ filename: String(file.name || ""), byte_length: Number(file.size || 0) }));
    return { filenames: result.cards.map((card) => card.filename), input_files: inputFiles, cards: result.cards, safe_to_append: result.cards.length === 0 && inputFiles.length === 0 };
  }

  function sameFilenameMultiset(left, right) {
    const normalize = (items) => (Array.isArray(items) ? items.map((item) => String(item?.filename || item || "").trim()).sort() : []);
    const a = normalize(left), b = normalize(right);
    return a.length === b.length && a.every((name, index) => name === b[index]);
  }

  function messageRows(doc = globalThis.document) {
    if (!isDotLocation() || !doc?.querySelectorAll) return [];
    return [...doc.querySelectorAll("article.message-row")];
  }

  function messageOrderSnapshot(doc = globalThis.document) {
    const rows = messageRows(doc);
    if (rows.length > 5000) return null;
    const ids = rows.map((row) => String(row.getAttribute("data-message-id") || "").trim());
    if (!rows.length || ids.some((id) => !id) || new Set(ids).size !== ids.length) return null;
    const selfRows = rows.filter((row) => row.classList?.contains?.("self"));
    const selfIds = selfRows.map((row) => String(row.getAttribute("data-message-id") || "").trim());
    if (selfIds.some((id) => !id) || new Set(selfIds).size !== selfIds.length || selfIds.some((id) => !ids.includes(id))) return null;
    return { message_ids: ids, self_message_ids: selfIds, last_message_id: ids[ids.length - 1] };
  }

  function validMessageOrderSnapshot(snapshot) {
    const ids = Array.isArray(snapshot?.message_ids) ? snapshot.message_ids.map((id) => String(id || "").trim()) : [];
    const selfIds = Array.isArray(snapshot?.self_message_ids) ? snapshot.self_message_ids.map((id) => String(id || "").trim()) : [];
    const anchor = String(snapshot?.last_message_id || "").trim();
    return ids.length > 0 && ids.every(Boolean) && new Set(ids).size === ids.length &&
      selfIds.every(Boolean) && new Set(selfIds).size === selfIds.length && selfIds.every((id) => ids.includes(id)) && anchor === ids[ids.length - 1];
  }

  function normalizeMessageText(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\r\n?/g, "\n").trim().replace(/\s+/g, " ");
  }

  function userMessageText(message) {
    if (!message?.matches?.("article.message-row.self[data-message-id]")) return null;
    const texts = [...message.querySelectorAll(".message-text[data-content-search-unit-key]")];
    if (texts.length !== 1) return null;
    return normalizeMessageText(texts[0].textContent || "");
  }

  function userMessageAttachmentNames(message) {
    if (!isDotLocation() || !message?.matches?.("article.message-row.self[data-message-id]")) return null;
    const lists = [...message.querySelectorAll(".attachment-list")];
    if (lists.length === 0) return [];
    if (lists.length !== 1) return null;
    const list = lists[0];
    const isCard = (node) => [...(node?.classList || [])].includes("group/resource-card");
    const isMessageSurface = (node) => [...(node?.classList || [])].includes("message-surface");
    const listChildren = [...(list.children || [])];
    let cards = [];
    if (listChildren.length === 1 && isMessageSurface(listChildren[0])) {
      const surfaceChildren = [...(listChildren[0].children || [])];
      if (!surfaceChildren.length || surfaceChildren.some((child) => !isCard(child))) return null;
      cards = surfaceChildren;
    } else {
      if (!listChildren.length || listChildren.some((child) => !isCard(child))) return null;
      cards = listChildren;
    }
    const names = [];
    for (const card of cards) {
      const openButtons = [...card.querySelectorAll('button[aria-label^="Открыть "][type="button"]')];
      const labels = [...card.querySelectorAll("span[title]")];
      const stateNodes = [card, ...card.querySelectorAll('[aria-busy], [data-state], [data-status], [data-upload-status], [data-error], [role="alert"]')];
      let busy = false;
      let error = false;
      for (const node of stateNodes) {
        const ariaBusy = String(node.getAttribute?.("aria-busy") || "").toLowerCase();
        const state = [node.getAttribute?.("data-state"), node.getAttribute?.("data-status"), node.getAttribute?.("data-upload-status")]
          .map((value) => String(value || "").toLowerCase()).join(" ");
        const errorAttr = node.getAttribute?.("data-error");
        busy ||= ariaBusy === "true" || /upload|loading|processing|загружа|обработ/.test(state);
        error ||= (errorAttr !== null && String(errorAttr).toLowerCase() !== "false") || /error|failed|ошиб|сбой/.test(state) || node.getAttribute?.("role") === "alert";
      }
      const children = [...(card.children || [])];
      if (openButtons.length !== 1 || labels.length !== 1 || busy || error || children.length !== 2 || !children.includes(openButtons[0])) return null;
      const other = children.find((child) => child !== openButtons[0]);
      if (other !== labels[0]) {
        if (!other || other.tagName?.toLowerCase() !== "div" || ![...(other.classList || [])].includes("pointer-events-none") || labels[0].parentElement !== other) return null;
        const allowedNested = new Set(["svg", "path", "span"]);
        const nested = [...other.querySelectorAll("*")];
        if (nested.some((node) => !allowedNested.has(node.tagName?.toLowerCase()) || (node !== labels[0] && node.tagName?.toLowerCase() === "span"))) return null;
      } else if (children.some((child) => child !== openButtons[0] && child !== labels[0])) return null;
      const filename = String(labels[0].getAttribute("title") || labels[0].textContent || "").trim();
      if (!filename || String(openButtons[0].getAttribute("aria-label") || "") !== `Открыть ${filename}` || String(openButtons[0].getAttribute("aria-busy") || "").toLowerCase() === "true") return null;
      names.push(filename);
    }
    return names;
  }

  function findNewMatchingUserMessage(entry, doc = globalThis.document) {
    const baselineIds = new Set(Array.isArray(entry?.baseline_message_ids) ? entry.baseline_message_ids.map(String) : []);
    const anchor = String(entry?.baseline_last_message_id || "");
    const expectedText = normalizeMessageText(entry?.send_marker || "");
    const expectedFiles = Array.isArray(entry?.expected_attachment_names) ? entry.expected_attachment_names.map(String) : [];
    if (!anchor || !expectedText || !validMessageOrderSnapshot({
      message_ids: entry?.baseline_message_ids, self_message_ids: entry?.baseline_self_message_ids, last_message_id: anchor
    })) return null;
    const live = messageOrderSnapshot(doc);
    if (!live) return null;
    const anchorIndex = live.message_ids.indexOf(anchor);
    if (anchorIndex < 0) return null;
    const matches = [];
    for (const message of doc.querySelectorAll("article.message-row.self[data-message-id]")) {
      const id = String(message.getAttribute("data-message-id") || "");
      const index = live.message_ids.indexOf(id);
      if (!id || baselineIds.has(id) || index <= anchorIndex) continue;
      if (userMessageText(message) !== expectedText) continue;
      const names = userMessageAttachmentNames(message);
      if (!names || !sameFilenameMultiset(names, expectedFiles)) continue;
      matches.push({ node: message, id, ordered_message_ids: live.message_ids.slice() });
    }
    return matches.length === 1 ? matches[0] : null;
  }

  globalThis.YMBDotSurface = Object.freeze({
    UUID, DOT_PATH, locationParts, dotIdFromPath, isDotLocation, hasDotNamespace, visible,
    assistantMessages, findCodeBlocks, codeSurface, textFromBlock, geometryAnchor, assistantRowId,
    dotComposerContext, dotSendButton, dotComposerShell, composerAttachmentCards, attachmentSnapshot,
    sameFilenameMultiset, messageRows, messageOrderSnapshot, validMessageOrderSnapshot,
    normalizeMessageText, userMessageText, userMessageAttachmentNames, findNewMatchingUserMessage
  });
})();
