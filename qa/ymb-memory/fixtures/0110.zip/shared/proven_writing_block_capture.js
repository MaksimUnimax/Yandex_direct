(() => {
  "use strict";

  function assistantContainerFor(node) {
    const dot = globalThis.YMBDotSurface;
    if (dot?.isDotLocation?.()) {
      const message = node?.closest?.('[data-orbit-message-parts="true"]') || null;
      const row = message?.closest?.("article.message-row[data-message-id]") || null;
      return message?.querySelector?.('[data-markdown-text-style="assistant-message"]') && row && !row.classList?.contains?.("self") ? message : null;
    }
    return node?.closest?.('[data-message-author-role="assistant"], article, [data-testid^="conversation-turn-"]') || null;
  }

  function isWholeResponseCopy(button) {
    if (!button) return false;
    const label = String(button.getAttribute?.("aria-label") || button.title || button.textContent || "").toLowerCase();
    const block = button.closest?.('pre, [data-testid="code-block"], .code-block, #code-block-viewer');
    return !block && /copy|копир/u.test(label);
  }

  function blockForCopy(button) {
    const dot = globalThis.YMBDotSurface;
    if (dot?.isDotLocation?.()) {
      if (!button?.isConnected) return null;
      const block = button.closest?.('[data-orbit-message-block="codeBlock"]') || null;
      if (!block || !assistantContainerFor(block) || !dot.findCodeBlocks(document).includes(block)) return null;
      const surface = dot.codeSurface(block);
      const copies = surface?.querySelectorAll?.('button[aria-label="Копировать"]') || [];
      return copies.length === 1 && copies[0] === button ? block : null;
    }
    if (!button || isWholeResponseCopy(button)) return null;
    const direct = button.closest?.('pre, [data-testid="code-block"], .code-block, #code-block-viewer');
    if (direct) return direct;
    const parent = button.parentElement;
    if (!parent) return null;
    const candidates = parent.querySelectorAll?.('pre, [data-testid="code-block"], .code-block, #code-block-viewer') || [];
    return candidates.length === 1 ? candidates[0] : null;
  }

  function textFromBlock(block) {
    if (!block) return "";
    const dot = globalThis.YMBDotSurface;
    if (dot?.isDotLocation?.()) return dot.findCodeBlocks(document).includes(block) ? dot.textFromBlock(block) : "";
    const cm = block.querySelector?.('.cm-content, [contenteditable="false"].cm-content');
    if (cm) return String(cm.innerText || cm.textContent || "").replace(/\r\n?/g, "\n");
    const code = block.querySelector?.('code');
    return String((code || block).innerText || (code || block).textContent || "").replace(/\r\n?/g, "\n");
  }

  function candidateBlocks(doc = document) {
    const dot = globalThis.YMBDotSurface;
    if (dot?.isDotLocation?.()) return dot.findCodeBlocks(doc);
    const out = [];
    const seen = new Set();
    for (const block of doc.querySelectorAll('pre, [data-testid="code-block"], .code-block, #code-block-viewer')) {
      if (seen.has(block) || !assistantContainerFor(block)) continue;
      seen.add(block); out.push(block);
    }
    return out;
  }

  globalThis.BB2ProvenWritingCapture = Object.freeze({ assistantContainerFor, isWholeResponseCopy, blockForCopy, textFromBlock, candidateBlocks });
})();
