(() => {
  "use strict";

  const NODE_IDS = new WeakMap();
  let nextNodeId = 1;

  class ComposerSendError extends Error {
    constructor(code, message = code) {
      super(message);
      this.name = "ComposerSendError";
      this.code = code;
    }
  }

  function nodeId(node) {
    if (!node || (typeof node !== "object" && typeof node !== "function")) return null;
    if (!NODE_IDS.has(node)) NODE_IDS.set(node, `node-${nextNodeId++}`);
    return NODE_IDS.get(node);
  }

  function normalize(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\r\n/g, "\n").trim().replace(/\s+/g, " ");
  }

  function visible(el) {
    if (!(el instanceof Element) || !el.isConnected) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function disabled(el) {
    return Boolean(el?.disabled || el?.getAttribute?.("aria-disabled") === "true");
  }

  function findComposer(doc = document) {
    if (globalThis.YMBDotSurface?.isDotLocation?.()) return globalThis.YMBDotSurface.dotComposerContext(doc)?.composer || null;
    const selectors = [
      '#prompt-textarea',
      '[data-testid="prompt-textarea"]',
      'div[contenteditable="true"][data-lexical-editor="true"]',
      'div[contenteditable="true"][role="textbox"]',
      'textarea[id*="prompt" i]',
      'textarea[data-testid*="prompt" i]',
      'textarea'
    ];
    for (const selector of selectors) {
      const el = doc.querySelector(selector);
      if (el?.isConnected) return el;
    }
    return null;
  }

  function readComposer(el) {
    if (!el) return "";
    if ("value" in el && typeof el.value === "string") return el.value;
    return String(el.innerText ?? el.textContent ?? "");
  }

  function setComposerText(el, text) {
    if (!el) return false;
    const value = String(text || "");
    el.focus?.();
    if ("value" in el && typeof el.value === "string") {
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value")?.set;
      if (setter) setter.call(el, value); else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
    el.textContent = value;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    return true;
  }

  function findSendButtonByProfile(doc, profile) {
    const selector = typeof profile?.selector === "string" ? profile.selector.trim() : "";
    if (!selector || selector.length > 600) return null;
    try {
      const el = doc.querySelector(selector);
      return el?.isConnected ? el : null;
    } catch { return null; }
  }

  function sendCandidates(root = document, profile = null) {
    if (globalThis.YMBDotSurface?.isDotLocation?.()) {
      const context = root?.root && root?.composer ? root : (root?.nodeType === 9 ? globalThis.YMBDotSurface.dotComposerContext(root) : null);
      const button = context ? globalThis.YMBDotSurface.dotSendButton(context) : null;
      return button ? [button] : [];
    }
    const result = [];
    const seen = new Set();
    const add = (el) => {
      if (!(el instanceof Element) || !el.isConnected || seen.has(el)) return;
      seen.add(el); result.push(el);
    };
    add(findSendButtonByProfile(root.ownerDocument || root, profile));
    for (const selector of [
      '#composer-submit-button',
      'button[data-testid="send-button"]',
      'button[aria-label="Send prompt"]',
      'button[aria-label="Send message"]',
      'button[aria-label*="Send" i]',
      'button[aria-label*="Отправ" i]'
    ]) {
      try { for (const el of root.querySelectorAll(selector)) add(el); } catch {}
    }
    return result;
  }

  function findSendButton(doc = document, profile = null) {
    if (globalThis.YMBDotSurface?.isDotLocation?.()) {
      const context = globalThis.YMBDotSurface.dotComposerContext(doc);
      const button = context ? globalThis.YMBDotSurface.dotSendButton(context) : null;
      return button && visible(button) && !disabled(button) ? button : null;
    }
    const composer = findComposer(doc);
    const form = composer?.closest?.("form") || null;
    const scoped = form ? sendCandidates(form, profile) : [];
    const candidates = scoped.length ? scoped : sendCandidates(doc, profile);
    return candidates.find((el) => visible(el) && !disabled(el)) || null;
  }

  // Preserve the legacy YMB meaning: true means the composer has returned to
  // its idle post-send state (voice/microphone action visible, no enabled Send,
  // and no remaining composer text). Generic text delivery relies on this.
  function composerReady(doc = document, profile = null) {
    const mic = doc.querySelector('button[aria-label*="voice" i], button[aria-label*="microphone" i], button[aria-label*="голос" i], button[aria-label*="микроф" i]');
    return Boolean(mic) && !findSendButton(doc, profile) && !readComposer(findComposer(doc)).trim();
  }

  function resolveContext(doc = document) {
    if (globalThis.YMBDotSurface?.isDotLocation?.()) return globalThis.YMBDotSurface.dotComposerContext(doc);
    const composer = findComposer(doc);
    if (!composer) return null;
    const form = composer.closest?.("form") || null;
    const root = form || composer.parentElement || doc.body || doc.documentElement;
    return { doc, composer, form, root };
  }

  function targetFingerprint(button) {
    if (!(button instanceof Element)) return null;
    return [
      nodeId(button),
      button.id || "",
      button.getAttribute("data-testid") || "",
      button.getAttribute("aria-label") || "",
      button.getAttribute("type") || "",
      normalize(button.textContent || "")
    ].join("|");
  }

  function snapshotTarget(target, deps) {
    const context = target?.context || null;
    const button = target?.button || null;
    const composer = context?.composer || null;
    const form = context?.form || null;
    const root = context?.root || form || null;
    const candidates = typeof deps?.candidateButtons === "function" ? deps.candidateButtons(context) : [];
    return {
      button_node_id: nodeId(button),
      composer_node_id: nodeId(composer),
      root_node_id: nodeId(root),
      form_node_id: nodeId(form),
      button_connected: Boolean(button?.isConnected),
      button_disabled: disabled(button),
      button_visible: Boolean(button && deps?.visible?.(button)),
      composer_connected: Boolean(composer?.isConnected),
      composer_visible: Boolean(composer && deps?.visible?.(composer)),
      root_connected: Boolean(root?.isConnected),
      form_connected: form ? Boolean(form.isConnected) : null,
      same_form: form ? Boolean(button && composer && button.closest?.("form") === form && composer.closest?.("form") === form) : null,
      same_root: !form ? Boolean(button && composer && root && root.contains?.(button) && root.contains?.(composer)) : null,
      candidate_send_buttons: Array.isArray(candidates) ? candidates.length : 0,
      button_fingerprint: typeof deps?.fingerprint === "function" ? deps.fingerprint(button) : targetFingerprint(button)
    };
  }

  function validateTarget(target, expectedText, deps) {
    if (!target?.context || !target?.button) return { ok: false, code: "SEND_TARGET_INCOMPLETE" };
    const { context, button } = target;
    const { composer, form } = context;
    const root = context.root || form || null;
    if (!composer?.isConnected) return { ok: false, code: "COMPOSER_DETACHED" };
    if (form) {
      if (!form.isConnected) return { ok: false, code: "COMPOSER_FORM_DETACHED" };
    } else if (!root?.isConnected) return { ok: false, code: "COMPOSER_FORM_DETACHED" };
    if (!button?.isConnected) return { ok: false, code: "BUTTON_DETACHED" };
    if (!deps.visible(composer)) return { ok: false, code: "COMPOSER_NOT_VISIBLE" };
    if (!deps.visible(button)) return { ok: false, code: "BUTTON_NOT_VISIBLE" };
    if (deps.disabled(button)) return { ok: false, code: "BUTTON_DISABLED" };
    if (form) {
      if (composer.closest("form") !== form || button.closest("form") !== form) return { ok: false, code: "BUTTON_COMPOSER_FORM_MISMATCH" };
    } else if (!root.contains(composer) || !root.contains(button)) {
      return { ok: false, code: "BUTTON_COMPOSER_FORM_MISMATCH" };
    }
    const composerValue = normalize(deps.readComposerText(composer));
    if (expectedText === null) {
      if (!composerValue) return { ok: false, code: "COMPOSER_EMPTY" };
    } else if (composerValue !== normalize(expectedText)) return { ok: false, code: "COMPOSER_TEXT_CHANGED" };
    if (typeof deps.requireAttachmentReady === "function" && !deps.requireAttachmentReady()) return { ok: false, code: "ATTACHMENT_NOT_READY" };
    if (typeof deps.sendBlockedReason === "function") {
      const reason = deps.sendBlockedReason(button, context);
      if (reason) return { ok: false, code: reason };
    }
    return { ok: true };
  }

  async function waitForValidatedTarget({ expectedText, timeoutMs = 10000, sampleIntervalMs = 100, requiredStableSamples = 3, deps }) {
    const deadline = Date.now() + timeoutMs;
    let stableSamples = 0;
    let previousKey = null;
    while (Date.now() < deadline) {
      const context = deps.resolveContext();
      const button = context ? deps.resolveButton(context) : null;
      const target = context && button ? { context, button } : null;
      const validation = validateTarget(target, expectedText, deps);
      if (validation.ok) {
        const candidates = typeof deps.candidateButtons === "function" ? deps.candidateButtons(context) : null;
        if (Array.isArray(candidates) && candidates.filter((item) => visible(item) && !disabled(item)).length > 1) {
          stableSamples = 0; previousKey = null;
        } else {
          const key = `${nodeId(context.composer)}|${nodeId(context.form || context.root)}|${nodeId(button)}`;
          stableSamples = key === previousKey ? stableSamples + 1 : 1;
          previousKey = key;
          if (stableSamples >= requiredStableSamples) return { ...target, stable_samples: stableSamples, snapshot: snapshotTarget(target, deps) };
        }
      } else { stableSamples = 0; previousKey = null; }
      await deps.sleep(sampleIntervalMs);
    }
    return null;
  }

  function createClickTrace(context, button) {
    const trace = {
      document_capture_seen: false,
      button_capture_seen: false,
      button_bubble_seen: false,
      form_submit_seen: false,
      click_is_trusted: null,
      click_default_prevented: null,
      submit_default_prevented: null
    };
    let clickEvent = null;
    let submitEvent = null;
    const onDocumentCapture = (event) => {
      if (event.target === button || button.contains?.(event.target)) {
        trace.document_capture_seen = true; clickEvent = event; trace.click_is_trusted = event.isTrusted;
      }
    };
    const onButtonCapture = (event) => { trace.button_capture_seen = true; clickEvent = event; trace.click_is_trusted = event.isTrusted; };
    const onButtonBubble = (event) => { trace.button_bubble_seen = true; clickEvent = event; };
    const onSubmitCapture = (event) => { trace.form_submit_seen = true; submitEvent = event; };
    document.addEventListener("click", onDocumentCapture, true);
    button.addEventListener("click", onButtonCapture, true);
    button.addEventListener("click", onButtonBubble, false);
    if (context.form) context.form.addEventListener("submit", onSubmitCapture, true);
    return {
      finish() {
        trace.click_default_prevented = clickEvent ? clickEvent.defaultPrevented : null;
        trace.submit_default_prevented = submitEvent ? submitEvent.defaultPrevented : null;
        document.removeEventListener("click", onDocumentCapture, true);
        button.removeEventListener("click", onButtonCapture, true);
        button.removeEventListener("click", onButtonBubble, false);
        if (context.form) context.form.removeEventListener("submit", onSubmitCapture, true);
        return trace;
      }
    };
  }

  function clickSynchronously({ target, expectedText, deps, beforeClick = null }) {
    const validation = validateTarget(target, expectedText, deps);
    if (!validation.ok) throw new ComposerSendError(validation.code, validation.code);
    const preClickSnapshot = snapshotTarget(target, deps);
    if (typeof beforeClick === "function") beforeClick(preClickSnapshot);
    const trace = createClickTrace(target.context, target.button);
    const method = "button.click";
    let clickTrace;
    try {
      target.button.click();
    } catch (error) {
      clickTrace = trace.finish();
      const wrapped = new ComposerSendError("BUTTON_CLICK_FAILED", error?.message || "button.click failed");
      wrapped.cause = error;
      wrapped.method_called = true;
      wrapped.method = method;
      wrapped.pre_click_snapshot = preClickSnapshot;
      wrapped.trace = clickTrace;
      wrapped.click_event_observed = Boolean(clickTrace.document_capture_seen || clickTrace.button_capture_seen || clickTrace.button_bubble_seen);
      throw wrapped;
    }
    clickTrace = trace.finish();
    return {
      method_called: true,
      method,
      pre_click_snapshot: preClickSnapshot,
      trace: clickTrace,
      click_event_observed: Boolean(clickTrace.document_capture_seen || clickTrace.button_capture_seen || clickTrace.button_bubble_seen)
    };
  }

  globalThis.BB2ComposerSend = Object.freeze({
    ComposerSendError, nodeId, normalize, visible, disabled,
    findComposer, readComposer, setComposerText, findSendButtonByProfile, sendCandidates, findSendButton, composerReady,
    resolveContext, targetFingerprint, snapshotTarget, validateTarget, waitForValidatedTarget, clickSynchronously
  });
})();
