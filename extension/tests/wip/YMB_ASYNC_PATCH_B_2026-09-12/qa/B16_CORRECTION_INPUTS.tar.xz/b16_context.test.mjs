// Exact file-delivery functions in VM. Browser navigation regression is separate.
import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
const source=fs.readFileSync(process.env.YMB_FILE_CONTENT,'utf8');
function fixture({at=null}={}){
 const calls=[],state={changes:0,clicks:0,marker:'',inputConnected:true},node={isConnected:true,style:{},textContent:'',remove(){this.isConnected=false;}};
 let ctx;
 const input={get isConnected(){return state.inputConnected;}},button={isConnected:true,click(){state.clicks++;},removeEventListener(){}};
 const descriptor={byte_length:4,artifact_key:'a',filename:'a.txt',chunk_manifest:[{chunk_index:0,byte_length:4,sha256:'hash'}]};
 const entry={conversation_key:'A',delivery_id:'d',report_text:'OLD_REPORT',phase:'claimed',artifact_descriptors:[descriptor]};
 const values={console,Set,HTMLElement:Object,Uint8Array,Error,Date,location:{href:'A'},document:{querySelector:()=>null,getElementById:()=>node},setTimeout:()=>1,clearTimeout:()=>{},
  BB2ConversationIdentity:{identityFromCandidates:([url])=>({status:'confirmed',conversation_key:url})},
  BB2ComposerSend:{findComposer:()=>({}),readComposer:()=>state.marker,setComposerText:(_e,t)=>{state.marker=t;},findSendButton:()=>button},
  YMBChatGPTFileAttachment:{fileInput:()=>input,base64ToBytes:()=>new Uint8Array([120,120,120,120]),sha256Hex:async()=>{if(at==='hash')ctx.location.href='B';return'hash';},createFile:(bytes)=>({bytes}),setInputFiles(){state.changes++;},attachmentReady:()=>true},
  chrome:{runtime:{lastError:null,sendMessage(m,cb){calls.push(m);queueMicrotask(()=>{
   if(at===m.type)ctx.location.href='B';
   if(at==='dispose_chunk'&&m.type==='WS_GET_OUTBOX_ARTIFACT_CHUNK')ctx.__test.runtime.disposed=true;
   if(at==='disconnect_chunk'&&m.type==='WS_GET_OUTBOX_ARTIFACT_CHUNK')state.inputConnected=false;
   const r=m.type==='WS_MARK_ATTACHMENT_COMMITTED'?{ok:true,outbox:entry}:m.type==='WS_GET_OUTBOX_ARTIFACT_CHUNK'?{ok:true,artifact_key:'a',chunk_index:0,total_byte_length:4,byte_length:4,sha256:'hash',chunk_base64:'eHh4eA=='}:{ok:true};cb(r);
  });}}},queueMicrotask};
 ctx=vm.createContext(values);ctx.globalThis=ctx;const marker='  runtime.timer = setTimeout(poll, 250);';assert.equal(source.split(marker).length,2);
 vm.runInContext(source.replace(marker,'  globalThis.__test={processClaimed,commitAndClick,stageMarker,runtime};'),ctx);
 return{ctx,state,calls,entry,button,run:()=>ctx.__test.processClaimed(entry),send:()=>ctx.__test.commitAndClick(entry,button)};
}
test('matching conversation still attaches and stages exactly once',async()=>{const f=fixture();await f.run();assert.equal(f.state.changes,1);assert.equal(f.state.marker,'OLD_REPORT');assert.equal(f.calls.filter(x=>x.type==='WS_MARK_ATTACHMENT_READY').length,1);});
for(const at of ['WS_MARK_ATTACHMENT_COMMITTED','WS_GET_OUTBOX_ARTIFACT_CHUNK','hash','dispose_chunk'])test('changed context at '+at+' cannot reach File input or composer',async()=>{const f=fixture({at});try{await f.run();}catch{}assert.equal(f.state.changes,0);assert.equal(f.state.marker,'');assert.equal(f.calls.filter(x=>x.type==='WS_MARK_ATTACHMENT_READY').length,0);});
test('detached file input fails without reattachment',async()=>{const f=fixture({at:'disconnect_chunk'});await assert.rejects(()=>f.run());assert.equal(f.state.changes,0);});
test('late commit reply in another conversation does not click Send',async()=>{const f=fixture({at:'WS_COMMIT_ATTACHMENT_SEND'});await f.send();assert.equal(f.state.clicks,0);assert.equal(f.ctx.__test.runtime.send_in_flight.size,0);});
test('already changed conversation starts no attachment commit',async()=>{const f=fixture();f.ctx.location.href='B';try{await f.run();}catch{}assert.equal(f.calls.length,0);assert.equal(f.state.changes,0);});
test('already changed conversation starts no Send commit',async()=>{const f=fixture();f.ctx.location.href='B';await f.send();assert.equal(f.calls.length,0);assert.equal(f.state.clicks,0);});
test('stage marker refuses wrong conversation without overwriting user text',()=>{const f=fixture();f.ctx.location.href='B';try{f.ctx.__test.stageMarker(f.entry);}catch{}assert.equal(f.state.marker,'');});
