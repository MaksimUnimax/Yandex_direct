"""Exact one-file B16 correction over the ready B15 artifact; internal QA only.
Usage: b16_apply_correction.py B15_ARTIFACT EMPTY_OUTPUT REPOSITORY_QA_DIR
Reuse B15's unchanged canonical metadata/packing algorithm. Never modifies input.
"""
from pathlib import Path
import copy,hashlib,importlib.util,io,json,sys,zipfile
H=lambda b:hashlib.sha256(b).hexdigest()
OLD='d4bdf57268ac904421797d7aad428c47981cee4c870bc549909696479f91ace9'
NEW='dd6d1ef016d4df3d9b4789cd2806f4d0a36202f93c4655e196e2eeda439f7c73'
BEFORE='7b4db94a527778722ee9bbd7b0d131789128dcaee78451f5886a7bddf1ae183a'
AFTER='83ae1351ab057f7cd768243c91060d2dc77e8fe0f5b378055437e47a110012b7'
PRE='baa1729159812f4c70e24498ee269ea7939f86ffb5094a19a5520eec9d47e9e7'
POST='655702fa5025e2a4dc87b2d2bb6647cf3b9c69bee88f4017150b35e8f511a9f2'
ROOT='ymb-b13-internal-qa-not-for-installation/'
def tree(files):return H(''.join(H(b)+'  '+n+'\n' for n,b in sorted(files.items())).encode())
def main():
 src,out,q=map(Path,sys.argv[1:]);assert not out.exists(),'exclusive output required'
 raw=(src/'candidate-b15-internal.zip').read_bytes();assert len(raw)==223544 and H(raw)==OLD
 builder=src/'b15_prepare_fix.py'
 assert H(builder.read_bytes())=='edae547d6277f1c233c0e2b338dd43eb2afdd25b4162ded87f7f41227b209987'
 spec=importlib.util.spec_from_file_location('b15packer',builder);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 diff=Path(__file__).with_name('B16_CONTEXT_GUARD.diff').read_bytes()
 assert H(diff)=='0e1e65d785d795a5d7b5169ae63c808324584e86e589de3a4c6d1eb2194ff9b4'
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  assert z.testzip() is None;infos=z.infolist();assert len(infos)==69 and len({i.filename for i in infos})==69
  files={i.filename[len(ROOT):]:z.read(i) for i in infos if not i.is_dir()}
 assert len(files)==67 and tree(files)==BEFORE and H(files[m.NAME])==PRE
 files[m.NAME]=m.patch(files[m.NAME],diff);assert H(files[m.NAME])==POST and tree(files)==AFTER
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for i in infos:z.writestr(copy.copy(i),b'' if i.is_dir() else files[i.filename[len(ROOT):]],compress_type=i.compress_type,compresslevel=9)
 new=buf.getvalue();assert len(new)==223870 and H(new)==NEW
 with zipfile.ZipFile(io.BytesIO(new)) as z:
  assert z.testzip() is None and {i.filename[len(ROOT):]:z.read(i) for i in z.infolist() if not i.is_dir()}==files
 tests={}
 for name,expected in [('b15_browser_qualification.mjs','0d085b321ef89ce671a28967c7d037d5d21844b6d485e8da9b4fa5c0cc5ebe94'),('b15_browser_faults.mjs','3480ca0aec9391a0b592e29b968c08fe11fd0d2a8832769b5383e7e43fcc40c6')]:
  b=(src/name).read_bytes();assert H(b)==expected;s=b.decode();assert s.count(BEFORE)==1;tests[name]=s.replace(BEFORE,AFTER).encode()
 body=(q/'b16_browser_cases.mjs').read_bytes();assert H(body)=='97093dc68e4f6a68ae1abba6fc16ba89fe0f9d906cbec6e9dd6c3f356fb6949d'
 s=body.decode()
 s=s.replace("  const before=await w.evaluate(async key=>({prefix:","  await w.evaluate(async({key,tabId})=>saveReportPrefixFromTab(key,{text:'PREVIOUSLY_SAVED_B16',enabled:false},tabId),{key:KEY,tabId});\n  const before=await w.evaluate(async key=>({prefix:",1)
 s=s.replace("  await resetDelivery();await page.evaluate(()=>{document.getElementById('conversation-root').replaceChildren();","  await resetDelivery();await w.evaluate(()=>chrome.storage.local.set({wsmb_auto_send:true}));await page.evaluate(()=>{document.getElementById('conversation-root').replaceChildren();",1)
 s=s.replace("if(m?.type==='WS_GET_OUTBOX_ARTIFACT_CHUNK'&&m.chunk_index===3&&r?.ok)","if(!__b16_chunk_held&&m?.type==='WS_GET_OUTBOX_ARTIFACT_CHUNK'&&m.chunk_index===3&&r?.ok)",1)
 assert H(s.encode())=='86015b06b5b89e22096c1dd84573eb8a3c154cde27ecd5210d7e7ac1c962aac6'
 tests['b16.generated.mjs']=tests['b15_browser_qualification.mjs'].decode().split('try{\n browser=await puppeteer.launch',1)[0].encode()+s.encode()
 tests['b15_fixture.html']=(src/'b15_fixture.html').read_bytes();assert H(tests['b15_fixture.html'])=='a2fd792336603d09c27fcd2a520a385ec85273f88741adc5cc0fd78047abbe72'
 send=(src/'b15_send_race.test.mjs').read_text().replace("document:{getElementById:()=>node}","document:{getElementById:()=>node,querySelector:()=>null},location:{href:'fixture'},BB2ConversationIdentity:{identityFromCandidates:()=>({status:'confirmed',conversation_key:'c'})}")
 assert H(send.encode())=='69a0abc8b011f7ea7c390e6722d533b367f868fca6100d01246377fce9956498'
 tests['b15_send_race.test.mjs']=send.encode();tests['b16_context.test.mjs']=Path(__file__).with_name('b16_context.test.mjs').read_bytes()
 out.mkdir(parents=True)
 (out/'candidate-b16-internal.zip').write_bytes(new)
 for name,b in files.items():p=out/'candidate'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for name,b in tests.items():p=out/'tests'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 (out/'IDENTITY.json').write_text(json.dumps({'package_sha256':NEW,'bytes':len(new),'tree_sha256':AFTER,'pre_tree_sha256':BEFORE,'changed':[m.NAME],'files':67,'unchanged_files':66,'release_allowed':False},indent=2)+'\n')
 (out/'QA_TARGETS.json').write_text(json.dumps({name:H(b) for name,b in tests.items()},indent=2)+'\n')
 print('EXACT_B16_CORRECTION',NEW,AFTER)
if __name__=='__main__':main()
