"""Exact two-file safety correction on ready B16; never owner release.
Usage: b17_prepare.py B16_BUNDLE JOB_ROOT EMPTY_OUTPUT
"""
from pathlib import Path
import sys,json,hashlib,zipfile,re,io,copy
sha=lambda b:hashlib.sha256(b).hexdigest()
PRE_ZIP='dd6d1ef016d4df3d9b4789cd2806f4d0a36202f93c4655e196e2eeda439f7c73'
PRE_TREE='83ae1351ab057f7cd768243c91060d2dc77e8fe0f5b378055437e47a110012b7'
POST_TREE='b20b74351d95becd67f32994e3e00899e9208b8c32c778a306f73f6703bfe508'
HASHES={'file_delivery_content.js':('655702fa5025e2a4dc87b2d2bb6647cf3b9c69bee88f4017150b35e8f511a9f2','8177c2ce023875aab75a03f348426f09e6f70d8b6a65c9b99d1c38a6f4ee5dcc','3f257d7e3b966eed22178eb294f3821ea32659a3aa1016230bc45072e3af0785'),'file_delivery_worker_transport.js':('3babc596ad6ea8baa6400cdadeb719d8d60fbbed6172d692af25283656eec81c','b9d87e44b43a352d6454a7ce1bb8ee3d36334302e8cafeb01924a046f5c4e43a','c2e36065366c7de34d649dc73e3f6483153fec4d4c5b08d606c093cb7dc4886d')}
def identity(files):return sha(''.join(sha(b)+'  '+n+'\n' for n,b in sorted(files.items())).encode())
def apply(before,diff,name):
 old=before.decode().splitlines(True);lines=diff.decode().splitlines(True)
 assert lines[:2]==['--- a/'+name+'\n','+++ b/'+name+'\n']
 out=[];i=2;cur=0
 while i<len(lines):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',lines[i]);assert m
  a,b,c,d=[int(x or 1) for x in m.groups()];assert a-1>=cur;out.extend(old[cur:a-1]);cur=a-1;assert len(out)==c-1;i+=1;r=w=0
  while i<len(lines) and not lines[i].startswith('@@ '):
   l=lines[i];assert l[0] in ' +-'
   if l[0] in ' -':assert old[cur]==l[1:];cur+=1;r+=1
   if l[0] in ' +':out.append(l[1:]);w+=1
   i+=1
  assert (r,w)==(b,d)
 out.extend(old[cur:]);return ''.join(out).encode()
def main():
 bundle,job,out=map(Path,sys.argv[1:]);assert not out.exists(),'Output must not exist'
 raw=(bundle/'candidate-b16-internal.zip').read_bytes();assert len(raw)==223870 and sha(raw)==PRE_ZIP
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  assert z.testzip() is None; infos=z.infolist();files={e.filename.split('/',1)[1]:z.read(e) for e in infos if not e.is_dir()};assert len(files)==67 and identity(files)==PRE_TREE
  for n,(pre,post,dh) in HASHES.items():
   d=(job/'evidence'/('B17_'+n+'.diff')).read_bytes();assert sha(d)==dh and sha(files[n])==pre
   files[n]=apply(files[n],d,n);assert sha(files[n])==post
  assert identity(files)==POST_TREE
  packed=io.BytesIO()
  with zipfile.ZipFile(packed,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as dst:
   for e in infos:dst.writestr(copy.copy(e),b'' if e.is_dir() else files[e.filename.split('/',1)[1]],compress_type=e.compress_type,compresslevel=9)
  data=packed.getvalue()
 tests={}
 for n,h in json.loads((bundle/'QA_TARGETS.json').read_text()).items():
  b=(bundle/'tests'/n).read_bytes();assert sha(b)==h
  if n.endswith('.mjs') and PRE_TREE.encode() in b:b=b.replace(PRE_TREE.encode(),POST_TREE.encode())
  tests[n]=b
 primary=tests['b15_browser_qualification.mjs'].decode();assert primary.count(" const domReady=await runCase(")==1
 prefix=primary.split(" const domReady=await runCase(")[0];tail=primary[primary.index(' assert.equal(tree(),target);emit({case:'):]
 tests['b17_browser.mjs']=(prefix+(job/'qa/b17_browser_cases.js').read_text()+'\n'+tail).encode()
 out.mkdir()
 for n,b in files.items():p=out/'candidate'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for n,b in tests.items():p=out/'tests'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 (out/'candidate-b17-internal.zip').write_bytes(data)
 (out/'IDENTITY.json').write_text(json.dumps({'package_sha256':sha(data),'bytes':len(data),'tree_sha256':POST_TREE,'pre_tree':PRE_TREE,'files':67,'changed':list(HASHES),'release_allowed':False},indent=2)+'\n')
 print((out/'IDENTITY.json').read_text())
if __name__=='__main__':main()
