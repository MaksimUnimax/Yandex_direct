// Appended to the hash-verified B16 primary harness prelude. No product injections.
async function pausedState(){return w.evaluate(async key=>{const e=await getConversationOutbox(key);return e?{id:e.delivery_id,paused:e.delivery_paused===true,phase:e.phase}:null;},KEY);}
async function extensionRealm(p=page){for(const r of p.extensionRealms())if((await r.extension())?.id===extensionId)return r;throw new Error('EXTENSION_REALM_MISSING');}
async function runtimeState(){return(await extensionRealm()).evaluate(()=>{const r=globalThis.__YMB_FILE_DELIVERY_CONTENT_V2__;return{inflight:r?.in_flight.size,send:r?.send_in_flight.size,paused:r?.local_pause_id,aborted:r?.controller?.signal.aborted,control:!!r?.control_button,manual:!!r?.manual_handler};});}
async function clickControl(){await until(async()=>page.$eval('#ymb-file-delivery-control',b=>!b.disabled).catch(()=>false),'PAUSE_CONTROL_MISSING');await page.click('#ymb-file-delivery-control');}
await runCase('explicit_pause_claimed_preserves_evidence_and_resume_delivers_once',async()=>{
 await resetDelivery();await page.$eval('#prompt-textarea',e=>e.value='KEEP_USER_TEXT');const d=await stageFile(1,'b17-before');const before=await fx();
 await clickControl();await until(async()=>(await pausedState())?.paused,'PAUSE_NOT_DURABLE');assert.equal((await pausedState()).phase,'claimed');
 await page.$eval('#prompt-textarea',e=>e.value='');await delay(1800);assert.equal((await fx()).changes,before.changes);assert.equal((await artifactGone(d.key)).meta,true);
 await clickControl();await until(async()=>(await fx()).sends.length===before.sends.length+1,'RESUME_NOT_DELIVERED');await until(async()=>!(await outbox()),'RESUME_NOT_ACKED');assert.deepEqual(await artifactGone(d.key),{remaining:0,meta:false});
 return{provider_cancelled:false,evidence_kept_while_paused:true,explicit_resume_send:1};
});
for(const mib of [1,10,32,64])await runCase('pause_inflight_'+mib+'MiB_releases_continuation_before_late_chunk',async()=>{
 await resetDelivery();await delay(1000);await w.evaluate(()=>{globalThis.__b17_held=false;globalThis.__b17_release=null;globalThis.__b17_base_handle=handleMessage;handleMessage=async(m,s)=>{const r=await __b17_base_handle(m,s);if(m?.type==='WS_GET_OUTBOX_ARTIFACT_CHUNK'&&!__b17_held){__b17_held=true;await new Promise(ok=>__b17_release=ok);}return r;};});
 const before=await fx(),d=await stageFile(mib,'b17-held-'+mib);await until(()=>w.evaluate(()=>__b17_held),'CHUNK_NOT_HELD');const memoryBefore=memory();await clickControl();
 await until(async()=>(await pausedState())?.paused,'INFLIGHT_PAUSE_NOT_SAVED');await until(async()=>(await runtimeState()).inflight===0,'CONTINUATION_RETAINED_AFTER_PAUSE');
 const stateBeforeLate=await runtimeState();assert.equal(stateBeforeLate.aborted,true);const counts=await messageCounts();await w.evaluate(()=>{__b17_release();__b17_release=null;handleMessage=__b17_base_handle;});
 await delay(1500);assert.equal((await fx()).changes,before.changes);assert.equal((await fx()).sends.length,before.sends.length);assert.equal((await messageCounts()).WS_GET_OUTBOX_ARTIFACT_CHUNK,counts.WS_GET_OUTBOX_ARTIFACT_CHUNK);assert.equal((await artifactGone(d.key)).meta,true);
 await clickControl();await delay(1600);assert.equal((await fx()).changes,before.changes,'resume after attachment commit is watch-only');assert.equal((await messageCounts()).WS_GET_OUTBOX_ARTIFACT_CHUNK,counts.WS_GET_OUTBOX_ARTIFACT_CHUNK);
 await resetDelivery();await delay(5000);return{mib,continuation_released_before_transport_reply:true,late_attachment:0,watch_only_resume:true,memoryBefore,after:memory(),storage_cleanup:'test fixture only; pause retained evidence intentionally',runtime:await runtimeState()};
});
await runCase('pause_ready_and_actual_worker_restart_then_watch_only_resume',async()=>{
 await resetDelivery();await w.evaluate(()=>chrome.storage.local.set({wsmb_auto_send:false}));const before=await fx(),d=await stageFile(1,'b17-ready');await until(async()=>(await outbox())?.phase==='attachment_ready','READY_MISSING');await clickControl();await until(async()=>(await pausedState())?.paused,'READY_PAUSE_NOT_SAVED');
 const changes=(await fx()).changes,old=await w.evaluate(()=>WORKER_SESSION_ID),oldTarget=wTarget;await w.close();await getWorker(oldTarget);await instrument();assert.notEqual(await w.evaluate(()=>WORKER_SESSION_ID),old);await delay(1600);
 assert.equal((await pausedState()).paused,true);assert.equal((await fx()).changes,changes);assert.equal((await fx()).sends.length,before.sends.length);
 await clickControl();await until(async()=>(await runtimeState()).manual,'MANUAL_WATCH_NOT_RESTORED');await page.click('#composer-submit-button');await until(async()=>!(await outbox()),'READY_RESUME_NOT_ACKED');assert.equal((await fx()).changes,changes);assert.equal((await fx()).sends.length,before.sends.length+1);assert.deepEqual(await artifactGone(d.key),{remaining:0,meta:false});await w.evaluate(()=>chrome.storage.local.set({wsmb_auto_send:true}));return{real_worker_restart:true,reattachment:0,one_explicit_send:true};
});
await runCase('durable_pause_survives_page_reload_without_reads_or_send',async()=>{
 await resetDelivery();await page.$eval('#prompt-textarea',e=>e.value='HOLD');const d=await stageFile(10,'b17-reload');await clickControl();await until(async()=>(await pausedState())?.paused,'PRE_RELOAD_PAUSE_MISSING');const counts=await messageCounts();await page.reload({waitUntil:'domcontentloaded'});await delay(2000);
 assert.equal((await pausedState()).paused,true);assert.equal((await fx()).changes,0);assert.equal((await fx()).sends.length,0);assert.equal((await messageCounts()).WS_GET_OUTBOX_ARTIFACT_CHUNK||0,counts.WS_GET_OUTBOX_ARTIFACT_CHUNK||0);assert.equal((await artifactGone(d.key)).meta,true);await resetDelivery();return{reload_pause_retained:true,automatic_materialization:0,artifact_deleted:false};
});
await runCase('pause_write_failure_is_locally_stopped_not_false_durable_success',async()=>{
 await resetDelivery();await page.$eval('#prompt-textarea',e=>e.value='HOLD');await stageFile(1,'b17-write-fault');await w.evaluate(()=>{globalThis.__b17_put=putOutbox;putOutbox=async(k,e)=>{if(e.delivery_paused)throw new Error('B17_PAUSE_DISK_FAILURE');return __b17_put(k,e);};});
 await clickControl();await until(async()=>page.$eval('#ymb-file-delivery-status',e=>e.textContent.includes('не подтверждено')).catch(()=>false),'PAUSE_ERROR_NOT_VISIBLE');assert.equal((await pausedState()).paused,false);assert.ok((await runtimeState()).paused);
 await page.$eval('#prompt-textarea',e=>e.value='');await delay(1500);assert.equal((await outbox()).phase,'claimed');await w.evaluate(()=>{putOutbox=__b17_put;});await clickControl();await until(async()=>(await pausedState())?.paused,'EXPLICIT_RETRY_NOT_SAVED');await resetDelivery();return{no_false_persisted_success:true,locally_stopped:true,explicit_retry_only:true};
});
await runCase('foreign_tab_pause_denied_and_source_operation_not_erased',async()=>{
 await resetDelivery();await page.$eval('#prompt-textarea',e=>e.value='HOLD');const d=await stageFile(1,'b17-owner');const p=await browser.newPage();await p.setRequestInterception(true);p.on('request',r=>{if(r.isNavigationRequest()&&r.url()===PAGE_URL)void r.respond({status:200,contentType:'text/html',body:fixture});else void r.abort();});await p.goto(PAGE_URL,{waitUntil:'domcontentloaded'});
 try{await delay(500);const r=await(await extensionRealm(p)).evaluate(({key,id})=>new Promise(ok=>chrome.runtime.sendMessage({type:'WS_SET_ATTACHMENT_PAUSED',conversation_key:key,delivery_id:id,paused:true},ok)),{key:KEY,id:d.id});assert.equal(r.ok,false);assert.equal(r.code,'AUTO_NON_OWNER_TAB');assert.equal((await pausedState()).paused,false);}finally{await p.close();}
 await resetDelivery();return{foreign_control_denied:true};
});
