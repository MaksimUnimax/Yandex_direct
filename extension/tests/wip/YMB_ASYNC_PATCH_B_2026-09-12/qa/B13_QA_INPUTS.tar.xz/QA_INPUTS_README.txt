B13 EXECUTABLE TEST INPUTS ONLY. NOT AN INSTALLABLE EXTENSION.
Original tests are preserved separately in source ref. Three explicit fixture/call-marker updates only.
