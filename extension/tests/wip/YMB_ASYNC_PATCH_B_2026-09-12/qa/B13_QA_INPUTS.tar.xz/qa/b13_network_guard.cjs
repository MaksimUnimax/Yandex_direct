// QA only: deny accidental external traffic; project VM tests install their own fixtures.
const fail = () => { throw new Error('B13_REAL_NETWORK_FORBIDDEN'); };
globalThis.fetch = fail;
for (const [module, keys] of [['node:http',['request','get']],['node:https',['request','get']],['node:net',['connect','createConnection']],['node:tls',['connect']],['node:dgram',['createSocket']]]) {
  const mod=require(module);for(const key of keys)mod[key]=fail;
}
